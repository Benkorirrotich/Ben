<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['fname'])==0)
	{	
header('location:index.php');
}
else{ 
if(isset($_POST['submit']))
  {
$sales=$_POST['sales'];
$advance=$_POST['advance'];
$Others=$_POST['Others'];
$tsales=$_POST['tsales'];
$remarks=$_POST['remarks'];
$date=$_POST['date'];
$sql="INSERT INTO `expenses`(`sales`, `advance`, `Others`, `tsales`,`date`)
 VALUES(:sales,:advance,:Others,:tsales,:date)";
$query = $dbh->prepare($sql);
$query->bindParam(':sales',$sales,PDO::PARAM_STR);
$query->bindParam(':advance',$advance,PDO::PARAM_STR);
$query->bindParam(':Others',$Others,PDO::PARAM_STR);
$query->bindParam(':tsales',$tsales,PDO::PARAM_STR);
$query->bindParam(':date',$date,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Details sent successfully";
}
else 
{
$error="Something went wrong. Please try again";
}
}
	include('includes/connection.php');
							 include_once("mainFunction/InsertRetriveEditDelFunctions.php");
                             $insertRetriveEditDelFunctions = new InsertRetriveEditDelFunctions();
		                   $query= "SELECT SUM(tbl.amount) AS total
   FROM ((SELECT amount FROM beauty WHERE DATE(date)= DATE(NOW()))
    UNION ALL
   (SELECT amount FROM haircut WHERE DATE(date)= DATE(NOW()))) tbl ";
                            $totalamount=0;
							$no=0;
		                    $result = $insertRetriveEditDelFunctions->getData($query);
                           forEach($result as $key=>$row){
                             //$total=$row['total']==0?"":number_format($row['total']);
	                       $total=$row['total'];
		
						   $totalamount +=$row['total'];
						
						   $no++;
	?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta advance="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta advance="description" content="">
	<meta advance="author" content="">
	<meta advance="theme-color" content="#3e454c">
<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta advance="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta advance="description" content="">
	<meta advance="author" content="">
	<meta advance="theme-color" content="#3e454c">
	<title>Ideal Barber and haircut Parlour</title>
	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
<style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
					
						<h2 class="page-title">Daily Expenses</h2>

						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<div class="panel-heading" style=
									"color:red"><?php
								$Today = date('y:m:d',mktime());
								$new = date('l, F d, Y', strtotime($Today));
								echo $new;
								?></div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
									<div class="panel-body">
<form id="form1" method="post" action="">
<form  method="post" class="form-horizontal" enctype="multipart/form-data">
<div class="form-group">
<label class="col-sm-2 control-label">Total Sales<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="sales" name="sales" Placeholder="Enter Total Sales" Value="<?php echo $total;?>" class="form-control" Readonly >
</div>
<br>
<label class="col-sm-2 control-label">Enter Advances<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number" name="advance" placeholder="Enter advance" class="form-control" required>
</div>
<br>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Other Expenses<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number" name="Others" placeholder="Enter Other Expenses" class="form-control" required>
</div><br>
<label class="col-sm-2 control-label">Sales After Deductions<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number" name="tsales" placeholder="" class="form-control" readonly>
</div>
</div><br>
<div class="form-group">
<label class="col-sm-2 control-label">Date<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="date" name="date" class="form-control" required>
</div><br>
<div class="col-sm-4">
<tr><td><input type="button" class="btn btn-danger" name="btn" value="Calculate" onclick="calc()"><input type="submit" class="btn btn-primary" name="submit" value="submit"><input type="reset" class="btn btn-default" value="clear"></td></tr>
</div>
</div><br>
<div class="form-group">
<div class="col-sm-8 col-sm-offset-2">

												</div>
											</div>
<div class="hr-dashed">
</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
</html>
<script>
    function calc()
    {
		form=document.getElementById("form1");
		 sales=form.sales.value;
        sales=parseFloat(sales);
	
      form.advance.value;
     form.Others.value;
     


      d=parseFloat(form.advance.value);
	  n=parseFloat(form.Others.value);
     
      
      form.tsales.value=parseFloat(sales-(d+n));
	
	}

</script>
<?php } }?>
