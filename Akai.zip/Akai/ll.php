<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<title>Employee Home</title>
	<link rel="stylesheet" href="css1/style.css" type="text/css" media="all" />
	<script type="text/javascript">
		function sureToApprove(id){
			if(confirm("Are you sure you want to delete this message?")){
				window.location.href ='delete_msg.php?id='+id;
			}
		}
	</script>
</head>
<body>
<!-- Header -->
<div id="header">
	<div class="shell">
		
		<?php
		
			include 'includes/menu.php';
		?>
		</div>
		<!-- End Main Nav -->
	</div>
</div>

<div id="container">
	<div class="shell">
		
		<div class="small-nav">
			<a href="index.php">Dashboard</a>
			<span>&gt;</span>
			Employee Salary Details
		</div>
		
		<br />
		
		<div id="main">
			<div class="cl">&nbsp;</div>
			
			<div id="content">
				
				<div class="box">
					<!-- Box Head -->
					<div class="box-head">
						<h2 class="left">Employee Salary Details</h2>
						<div class="right">
						 <form  method="post" action="">
							<label>search your salary using Id</label>
							
							<input type="text" name="searchById" class="field small-field" />
							<input type="submit" name="submit" class="button" value="search" />
						</div>
					</div>
					
					<div class="table">
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr>
								
								<th>First Name</th>
								<th>second Name</th>
								<th>sir Name</th>
								<th>Id Number</th>
								<th>Employee no</th>
								<th>Mobile Number</th>
								<th>Gross Salary</th>
								<th>NSSF</th>
								<th>NHIF</th>
								<th>PAYEE</th>
								<th>PERSONAL RELIEF</th>
								<th>INSURANCE RELIEF</th>
								<th>Net Salary</th>
								<th>Date</th>
								
								
							</tr>
							<?php
							session_start();
							 include_once("mainFunction/InsertRetriveEditDelFunctions.php");
                             include_once("mainFunction/Validation.php");
                             $insertRetriveEditDelFunctions = new InsertRetriveEditDelFunctions();
                             $validation = new Validation();
                             if(isset($_POST['submit'])){
								 
	                         $idno=$_SESSION['idno'];
							 echo $idno;
							$idNumber=$insertRetriveEditDelFunctions->escape_String($_POST['searchById']);
							 echo $idno;
	                         //$checkId = $validation->is_Id_Valid($_POST['searchById']);
	                          //if(!$checkId){
				             // echo"please provide valid id number it contain numbers only";
		 	                 //}
							 if($idNumber==$idno){
							
		                       
		                   $query= "SELECT * FROM `employeesalarydetails` WHERE	`IdNumber`=$idno";	
		                    $result = $insertRetriveEditDelFunctions->getData($query);
                           forEach($result as $key=>$row){
	                       $firstName=$row['firstName'];
	                       $secondName=$row['secondName'];
	                       $sirName=$row['sirName'];
	                       $idNumber=$row['IdNumber'];
	                       $employee_no=$row['employeeNumber'];
	                       $mobileNumber=$row['mobileNumber'];
                           $grossSalary=$row['grossSalary'];
   						   $nSSF=$row['nSSF'];
						   $nHIF=$row['nHIF'];
						   $pAYEE=$row['pAYEE'];
						   $PersonalRelief=$row['PersonalRelief'];
						   $InsuranceRelief=$row['InsuranceRelief'];
						   $netSalary=$row['netSalary'];
						   $date=$row['date'];
						   ?>
								
							<tr>
								
								<td><h3><a href="#"><?php echo $firstName;?></a></h3></td>
								<td><h3><a href="#"><?php echo $secondName;?></a></h3></td>
								<td><h3><a href="#"><?php echo $sirName;?></a></h3></td>
								<td><h3><a href="#"><?php echo $idNumber;?></a></h3></td>
								<td><h3><a href="#"><?php echo $employee_no;?></a></h3></td>
								<td><h3><a href="#"><?php echo $mobileNumber;?></a></h3></td>
								<td><h3><a href="#"><?php echo number_format($grossSalary);?></a></h3></td>
								<td><h3><a href="#"><?php echo number_format($nSSF);?></a></h3></td>
								<td><h3><a href="#"><?php echo number_format($nHIF);?></a></h3></td>
								<td><h3><a href="#"><?php echo number_format($pAYEE);?></a></h3></td>
								<td><h3><a href="#"><?php echo number_format($PersonalRelief);?></a></h3></td>
								<td><h3><a href="#"><?php echo number_format($InsuranceRelief);?></a></h3></td>
								<td><h3><a href="#"><?php echo number_format($netSalary);?></a></h3></td>
								<td><h3><a href="#"><?php echo  $date;?></a></h3></td>
								
								
							</tr>

									<?php
								}
						   
							 						}
						else if($idNumber !==$idno){
							echo"<font color='red'>sorry! you are using different ID Number";
						}
						else{
							echo"<font color='red'>there is no such person";
						}
						}
							?>
						</table>
					
						
						<!-- Pagging -->
						<div class="pagging">
							<div class="left">Showing 1-12 of 44</div>
							<div class="right">
								<a href="#">Previous</a>
								<a href="#">1</a>
								<a href="#">2</a>
								<a href="#">3</a>
								<a href="#">4</a>
								<a href="#">245</a>
								<span>...</span>
								<a href="#">Next</a>
								<a href="#">View all</a>
							</div>
						</div>
						<!-- End Pagging -->
						
					</div>
					<h2><input type="submit" onclick="window.print()" value="Print Here" /></h2>
					
				</div>
				<!-- End Box -->

			</div>
			<!-- End Content -->
							
			<!-- Sidebar -->
			
			
			<div class="cl">&nbsp;</div>			
		</div>
		<!-- Main -->
	</div>
</div>
<!-- End Container -->

<!-- Footer -->
<div id="footer">
	<div class="shell">
		<span class="left">&copy; <?php echo date("Y");?> - KE 348 FPFK</span>
		<span class="right">
			<a>Designed by Leon Kip.</a>
		</span>
	</div>
</div>
<!-- End Footer -->
</form>	
</body>
</html>