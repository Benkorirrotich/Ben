<?php
session_start();
error_reporting(0);
include('includes/config.php');
   include('includes/connection.php');
if(strlen($_SESSION['fname'])==0)
	{	
header('location:index.php');
}
else{ 
if(isset($_POST['submit']))
  {
//$date=$_POST['date'];
$date= date('Y-m-d h:i:s',strtotime($_POST['date'].' '.$_POST['time']));
$name=$_POST['name'];
$service=$_POST['service'];
$amount=$_POST['amount'];
$commission=$_POST['commission'];
$tcommission=$_POST['tcommission'];
$headwash=$_POST['headwash'];
$mode=$_POST['mode'];
$center=$_POST['center'];
$timeIn=$_POST['timeIn'];
$timeout=$_POST['timeout'];
$timetaken=$_POST['timetaken'];
$sql="INSERT INTO beauty(date,name,service,amount,commission,tcommission,headwash,mode,center,timeIn,
timeout,timetaken) VALUES(:date,:name,:service,:amount,:commission,:tcommission,:headwash,
:mode,:center,:timeIn,:timeout,:timetaken)";
$query = $dbh->prepare($sql);
$query->bindParam(':date',$date,PDO::PARAM_STR);
$query->bindParam(':name',$name,PDO::PARAM_STR);
$query->bindParam(':service',$service,PDO::PARAM_STR);
$query->bindParam(':amount',$amount,PDO::PARAM_STR);
$query->bindParam(':commission',$commission,PDO::PARAM_STR);
$query->bindParam(':tcommission',$tcommission,PDO::PARAM_STR);
$query->bindParam(':headwash',$headwash,PDO::PARAM_STR);
$query->bindParam(':mode',$mode,PDO::PARAM_STR);
$query->bindParam(':center',$center,PDO::PARAM_STR);
$query->bindParam(':timeIn',$timeIn,PDO::PARAM_STR);
$query->bindParam(':timeout',$timeout,PDO::PARAM_STR);
$query->bindParam(':timetaken',$timetaken,PDO::PARAM_STR);
$query->execute();
$lastInsertId = $dbh->lastInsertId();
if($lastInsertId)
{
$msg="Details sent successfully";
}
else 
{
$error="Something went wrong. Please try again";
}
}
?>
	<script>
    function calc()
    {
		form=document.getElementById("form1");
		 amount=form.amount.value;
        amount=parseFloat(amount);
     form.headwash.value;
      form.commission.value=(amount*40/100);
      h=parseFloat(form.commission.value);
	  n=parseFloat(form.headwash.value);
      
      form.tcommission.value=parseFloat((n+h));
		}

</script>
<!doctype html>
<html lang="en" class="no-js">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Ideal Barber and Beauty Parlour</title>
<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
<style>
		.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
		</style>
</head>
<body>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Beauticians Services</h2>
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<div class="panel-heading">Record Info Here!
									</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

									<div class="panel-body">
<form  id="form1" method="post" class="form-horizontal" enctype="multipart/form-data">
<div class="form-group">
<label class="col-sm-2 control-label">Date<span style="color:red">*</span></label>
<div class="col-sm-4">
<td class="form-control" ><input  name="date" type="date"  required>
    <input name="time" type="time"  required></td>
</div>

<label class="col-sm-2 control-label">Select Name<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="selectpicker" name="name" required>
<option value=""> Select Beautician </option>
<?php $ret="select id,name from staff";
$query= $dbh -> prepare($ret);
//$query->bindParam(':id',$id, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
if($query -> rowCount() > 0)
{
foreach($results as $result)
{
?>
<option value="<?php echo htmlentities($result->name);?>"><?php echo htmlentities($result->name);?></option>
<?php }} ?>

</select>
</div>
											
<div class="hr-dashed"></div>
<div class="form-group">
<label class="col-sm-2 control-label">Service Offered<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="service" placeholder="Enter name" class="form-control" required>
</div>
<label class="col-sm-2 control-label">Amount Paid<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="amount" placeholder="Enter amount"  class="form-control" required>
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Commision<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="commission" placeholder="" class="form-control" readonly>
</div>
<label class="col-sm-2 control-label">Total Commission<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="tcommission" placeholder=""  class="form-control"Required readonly>
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Head Wash<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="Number" name="headwash"  placeholder="Enter Amount.Eg 25" class="form-control" required>
</div>
<label class="col-sm-2 control-label">Time In<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="time" name="timeIn" placeholder="Enter time" class="form-control" >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Time Out<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="time" name="timeout" placeholder="Enter time" class="form-control" >
</div>
<label class="col-sm-2 control-label">Time Spent<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="timetaken" placeholder="Enter time" class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Select Payment Mode<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="selectpicker" name="mode" required>
<option value=""> Select Payment Mode </option>
<option value="MPESA">MPESA</option>
<option value="Cash">Cash</option>
</select>
</div>
<label class="col-sm-2 control-label">Select Working Station<span style="color:red">*</span></label>
<div class="col-sm-4">
<select class="selectpicker" name="center" required>
<option value=""> Select Working Station </option>
<option value="AKAIPLAZA">AKAI PLAZA</option> 
<option value="Ruiru">RUIRU</option>
</select>
</div>
</div>
<div class="hr-dashed"></div>
											<div class="form-group">
												<div class="col-sm-8 col-sm-offset-2">
<tr><td><input type="button" class="btn btn-danger" name="btn" value="Calculate" onclick="calc()"><input type="submit" class="btn btn-primary" name="submit" value="submit"><input type="reset" class="btn btn-default" value="clear"></td></tr>

												</div>
											</div>

										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
</body>
</html>
<?php } ?>
