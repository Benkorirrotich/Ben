<div id="sModal" class="modal fade">

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
			<p>Reports per Individual</p> 
				<form method="post" action="specificsearch.php" class="form-horizontal" enctype="multipart/form-data">
<div class="form-group">
<label class="col-sm-2 control-label">From Date<span style="color:red"></span></label>
<div class="col-sm-8">
<td class="form-control" ><input  name="date1" type="date"  required>
    <input name="time1" type="time"  required></td>                                          
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">To Date<span style="color:red"></span></label>
<div class="col-sm-8">
<td class="form-control" ><input  name="date2" type="date"  required>
    <input name="time2" type="time"  required></td>                                            
</div>

</div>
<div class="form-group">
<label class="col-sm-2 control-label">Select Name <span style="color:red"></span></label>
<div class="col-sm-8">
  <div class="col-sm-8">
				     
					   <select class="form-control" name="name" placeholder="~~SELECT~~"> 
				      	<option value=""><?php showAllData();?></option>
				      	<?php 
				      	function showAllData(){
    include('includes/connection.php');
    $query = "SELECT * FROM staff";
    $result = mysqli_query($con, $query);

    if(!$result){
        die('Query Failed'. mysqli_error());
    }
    while($row = mysqli_fetch_assoc($result)){
        $name = $row['name'];
       // echo $id;
        echo "<option name='$name'>$name</option>";
    } 
}
								
				      	?>
				      </select>
				    </div>                                      
</div>

</div>
<div class="hr-dashed"></div>






											<div class="form-group">
												<div class="col-sm-8 col-sm-offset-2">
													<button type="button" class="btn btn-danger wow fadeInDown" data-dismiss="modal">Close</button>
													<button class="btn btn-info wow fadeInDown" name="submit" type="submit">View</button>
												
												</div>
												
											</div>

										</form>
            </div>
        </div>
    </div>
</div>