-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2021 at 11:34 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idealbarber`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `lname`, `username`, `password`, `Regdate`) VALUES
(1, 'Ben', 'Korir', 'Ben', 'Ben@ben1', '2021-08-20 10:14:11'),
(3, 'karimi', 'karimi', 'karimi', 'karimi1', '2021-08-23 14:40:11'),
(4, 'purity', 'purity', 'purity', 'purity1', '2021-10-08 09:22:01');

-- --------------------------------------------------------

--
-- Table structure for table `beauty`
--

CREATE TABLE `beauty` (
  `id` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `timeIn` varchar(200) NOT NULL,
  `timeout` varchar(200) NOT NULL,
  `timetaken` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `beauty`
--

INSERT INTO `beauty` (`id`, `date`, `name`, `service`, `amount`, `mode`, `center`, `timeIn`, `timeout`, `timetaken`, `availability`, `Regdate`) VALUES
(12, '2021-08-23', 'nelly', 'nails cut', '200', 'MPESA', 'AKAIPLAZA', '19:29', '20:30', '1 hr', 1, '2021-08-23 14:28:55'),
(13, '2021-08-23', 'mary', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '14:52', '15:57', '1  hr 5 mins', 1, '2021-08-24 05:59:22'),
(14, '2021-08-23', 'mary', 'pedicure', '1500', 'MPESA', 'AKAIPLAZA', '16:12', '16:57', '45 mins', 1, '2021-08-24 05:59:22'),
(15, '2021-08-23', 'mary', 'facial', '2000', 'Cash', 'AKAIPLAZA', '17:06', '18:05', '59 mins', 1, '2021-08-24 05:59:22'),
(16, '2021-08-23', 'brenda', 'swedish massage', '2000', 'Cash', 'AKAIPLAZA', '17:00', '18:02', '1 hr 2 mins', 1, '2021-08-24 05:59:22'),
(17, '2021-08-23', 'brenda', 'swedish massage', '2000', 'Cash', 'AKAIPLAZA', '16:11', '17:13', '1 hr 2 mins', 1, '2021-08-24 05:59:22'),
(18, '2021-08-23', 'damaris', 'nails cut', '300', 'MPESA', 'AKAIPLAZA', '21:05', '21:35', '30 mins', 1, '2021-08-24 05:59:22'),
(19, '2021-08-23', 'damaris', 'face scrub', '1000', 'MPESA', 'AKAIPLAZA', '18:14', '18:46', '32 mins', 1, '2021-08-24 05:59:22'),
(20, '2021-08-23', 'liz', 'face scrub', '1000', 'MPESA', 'AKAIPLAZA', '22:21', '22:54', '33 mins', 1, '2021-08-24 05:59:22'),
(21, '2021-08-23', 'liz', 'face scrub', '600', 'MPESA', 'AKAIPLAZA', '23:23', '23:58', '35 mins', 1, '2021-08-24 05:59:22'),
(23, '2021-08-23', 'carol', 'nails cut', '500', 'MPESA', 'AKAIPLAZA', '18:04', '18:30', '26', 1, '2021-08-24 05:59:22'),
(24, '2021-08-24', 'mary', 'back massage', '1500', 'MPESA', 'AKAIPLAZA', '09:54', '22:24', '30 mins', 1, '2021-08-26 06:36:07'),
(25, '2021-08-24', 'mary', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '13:25', '14:29', '1hr 4mins', 1, '2021-08-26 06:36:07'),
(26, '2021-08-24', 'damaris', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '13:55', '15:05', '1 hr 10 mins', 1, '2021-08-26 06:36:07'),
(27, '2021-08-26', 'damaris', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '09:10', '08:47', '37 mins', 1, '2021-08-26 18:35:06'),
(28, '2021-08-26', 'nelly', 'face scrub', '1000', 'MPESA', 'AKAIPLAZA', '10:10', '10:42', '32 mins', 1, '2021-08-26 18:35:06'),
(29, '2021-08-26', 'mary', 'swedish massage', '2500', 'MPESA', 'AKAIPLAZA', '12:30', '13:04', '34 mins', 1, '2021-08-26 18:35:06'),
(31, '2021-08-26', 'nelly', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '17:16', '18:18', '1 hr 2 mins', 1, '2021-08-26 18:35:06'),
(32, '2021-08-26', 'nelly', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '19:10', '20:15', '1  hr 5 mins', 1, '2021-08-26 18:35:06'),
(33, '2021-08-26', 'nelly', 'face scrub', '500', 'MPESA', 'AKAIPLAZA', '15:19', '15:55', '36 mins', 1, '2021-08-26 18:35:06'),
(34, '2021-08-26', 'carol', 'face scrub', '1500', 'MPESA', 'AKAIPLAZA', '19:20', '20:00', '40 mins', 1, '2021-08-26 18:35:06'),
(35, '2021-08-26', 'brenda', 'swedish massage', '2500', 'MPESA', 'AKAIPLAZA', '20:09', '21:08', '59 mins', 1, '2021-08-26 18:35:06'),
(36, '2021-08-26', 'brenda', 'face scrub', '1000', 'Cash', 'AKAIPLAZA', '18:32', '19:11', '39 mins', 1, '2021-08-26 18:35:06'),
(37, '2021-08-26', 'damaris', 'pedicure', '1000', 'MPESA', 'AKAIPLAZA', '19:40', '21:20', '1 hr', 1, '2021-08-26 18:35:06'),
(40, '2021-08-27', 'mary', 'swedish massage', '3000', 'MPESA', 'AKAIPLAZA', '06:30', '07:15', '45 mins', 1, '2021-08-28 07:03:12'),
(41, '2021-08-27', 'brenda', 'swedish massage', '2000', 'Cash', 'AKAIPLAZA', '06:55', '08:05', '1 hr', 1, '2021-08-28 07:03:12'),
(42, '2021-08-27', 'damaris', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '03:10', '04:02', '58 mins', 1, '2021-08-28 07:03:12'),
(43, '2021-08-27', 'nelly', 'swedish massage', '3000', 'MPESA', 'AKAIPLAZA', '11:20', '00:48', '1 hr  28 mins', 1, '2021-08-28 07:03:12'),
(44, '2021-08-27', 'carol', 'manicure', '600', 'Cash', 'AKAIPLAZA', '10:10', '10:57', '47 mins', 1, '2021-08-28 07:03:12'),
(45, '2021-08-27', 'carol', 'face scrub', '1000', 'MPESA', 'AKAIPLAZA', '10:01', '10:34', '33 mins', 1, '2021-08-28 07:03:12'),
(46, '2021-08-27', 'shiru', 'face scrub', '1000', 'MPESA', 'AKAIPLAZA', '02:05', '02:44', '39 mins', 1, '2021-08-28 07:03:12'),
(47, '2021-08-28', 'carol', 'swedish massage', '2500', 'MPESA', 'AKAIPLAZA', '23:02', '12:08', '1 hr 6mins', 1, '2021-08-28 17:47:39'),
(48, '2021-08-28', 'shiru', 'face scrub', '1000', 'Cash', 'AKAIPLAZA', '14:04', '14:54', '50 mins', 1, '2021-08-28 17:47:39'),
(49, '2021-08-28', 'mary', 'manicure', '700', 'MPESA', 'AKAIPLAZA', '16:20', '17:00', '40 mins', 1, '2021-08-28 17:47:39'),
(50, '2021-08-28', 'nelly', 'back massage', '1500', 'MPESA', 'AKAIPLAZA', '18:00', '18:30', '30 mins', 1, '2021-08-28 17:47:39'),
(51, '2021-08-28', 'mary', 'swedish massage', '3000', 'MPESA', 'AKAIPLAZA', '20:46', '21:51', '1  hr 5 mins', 1, '2021-08-28 17:47:39'),
(52, '2021-08-29', 'carol', 'head scrub', '500', 'MPESA', 'AKAIPLAZA', '22:13', '12:43', '30 mins', 1, '2021-08-29 17:34:05'),
(53, '2021-08-29', 'nelly', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '22:07', '23:14', '1 hr 7 mins', 1, '2021-08-29 17:34:05'),
(54, '2021-08-29', 'nelly', 'nails cut', '300', 'MPESA', 'AKAIPLAZA', '12:18', '12:38', '20 mins', 1, '2021-08-29 17:34:05'),
(55, '2021-08-29', 'nelly', 'cleansing', '300', 'MPESA', 'AKAIPLAZA', '13:04', '13:30', '26 mins', 1, '2021-08-29 17:34:05'),
(56, '2021-08-29', 'nelly', 'nails cut', '300', 'MPESA', 'AKAIPLAZA', '17:08', '17:38', '30 mins', 1, '2021-08-29 17:34:05'),
(57, '2021-08-30', 'mary', 'swedish massage', '2500', 'MPESA', 'AKAIPLAZA', '16:09', '17:07', '58 mins', 1, '2021-08-30 16:22:19'),
(58, '2021-08-30', 'carol', 'swedish massage', '2500', 'MPESA', 'AKAIPLAZA', '17:15', '18:52', 'i hr 37 mins', 1, '2021-08-30 16:22:19'),
(59, '2021-08-30', 'mary', 'swedish massage', '3000', 'MPESA', 'AKAIPLAZA', '18:40', '19:42', '1 hr 2 mins', 1, '2021-08-30 16:22:19'),
(60, '2021-08-30', 'shiru', 'swedish massage', '3000', 'MPESA', 'AKAIPLAZA', '18:41', '19:44', '1 hr 3 mins', 1, '2021-08-30 16:22:19'),
(61, '2021-08-31', 'liz', 'face scrub', '700', 'MPESA', 'AKAIPLAZA', '10:04', '10:45', '41 mins', 1, '2021-08-31 17:05:00'),
(62, '2021-08-31', 'mary', 'swedish massage', '3000', 'MPESA', 'AKAIPLAZA', '12:19', '13:10', '1 hr 1 min', 1, '2021-08-31 17:05:00'),
(63, '2021-08-31', 'shiru', 'nails cut', '300', 'MPESA', 'AKAIPLAZA', '23:02', '23:33', '31 mins', 1, '2021-08-31 17:05:00'),
(64, '2021-08-31', 'brenda', 'swedish massage', '2500', 'MPESA', 'AKAIPLAZA', '15:06', '16:54', '1 hr', 1, '2021-08-31 17:05:00'),
(65, '2021-09-02', 'nelly', 'hair colour', '1000', 'MPESA', 'AKAIPLAZA', '23:41', '12:12', '33 mins', 1, '2021-09-02 16:44:25'),
(66, '2021-09-02', 'brenda', 'swedish massage', '2000', 'MPESA', 'AKAIPLAZA', '13:45', '14:45', '1hr', 1, '2021-09-02 16:44:25'),
(67, '2021-09-02', 'nelly', 'threading', '300', 'MPESA', 'AKAIPLAZA', '16:40', '16:50', '10 mins', 1, '2021-09-02 16:44:25'),
(68, '2021-09-02', 'damaris', 'face scrub', '800', 'MPESA', 'AKAIPLAZA', '14:36', '15:47', '31 mins', 1, '2021-09-02 16:44:25');

-- --------------------------------------------------------

--
-- Table structure for table `haircut`
--

CREATE TABLE `haircut` (
  `id` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `hwash` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `haircut`
--

INSERT INTO `haircut` (`id`, `date`, `name`, `service`, `amount`, `mode`, `center`, `hwash`, `availability`, `Regdate`) VALUES
(11, '2021-08-23', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(12, '2021-08-23', 'njogu', 'beard cut', '200', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-24 05:59:28'),
(13, '2021-08-23', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-24 05:59:28'),
(14, '2021-08-23', 'njogu', 'hair colour', '600', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-24 05:59:28'),
(15, '2021-08-23', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-24 05:59:28'),
(16, '2021-08-23', 'njogu', 'beard cut', '200', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-24 05:59:28'),
(17, '2021-08-23', 'njogu', 'hair colour', '300', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-24 05:59:28'),
(18, '2021-08-23', 'mwangi', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-24 05:59:28'),
(19, '2021-08-23', 'mwangi', 'beard cut', '200', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-24 05:59:28'),
(20, '2021-08-23', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-24 05:59:28'),
(21, '2021-08-23', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(22, '2021-08-23', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(23, '2021-08-23', 'njogu', 'hair colour', '1000', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(24, '2021-08-23', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-24 05:59:28'),
(25, '2021-08-24', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 06:36:21'),
(26, '2021-08-24', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-26 06:36:21'),
(27, '2021-08-24', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 06:36:21'),
(28, '2021-08-24', 'njogu', 'beard cut', '200', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-26 06:36:21'),
(29, '2021-08-24', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly ', 1, '2021-08-26 06:36:21'),
(30, '2021-08-24', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-26 06:36:21'),
(31, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 18:20:45'),
(32, '2021-08-26', 'njogu', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'mary', 1, '2021-08-26 18:20:45'),
(33, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-26 18:20:45'),
(34, '2021-08-26', 'njogu', 'hair colour', '600', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(35, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 18:20:45'),
(36, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-26 18:20:45'),
(37, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-26 18:20:45'),
(38, '2021-08-26', 'njogu', 'hair cut', '400', 'Cash', 'AKAIPLAZA', '4', 1, '2021-08-26 18:20:45'),
(39, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(40, '2021-08-26', 'fredy', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(41, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-26 18:20:45'),
(42, '2021-08-26', 'njogu', 'hair cut', '300', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(43, '2021-08-26', 'njogu', 'hair cut', '300', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-26 18:20:45'),
(44, '2021-08-26', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-26 18:36:27'),
(45, '2021-08-27', 'njogu', 'kid cut', '250', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-28 06:41:02'),
(46, '2021-08-27', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 06:41:02'),
(47, '2021-08-27', 'njogu', 'beard cut', '200', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-28 06:41:02'),
(48, '2021-08-27', 'njogu', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(49, '2021-08-27', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(50, '2021-08-27', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 06:41:02'),
(51, '2021-08-27', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-28 06:41:02'),
(52, '2021-08-27', 'mwangi', 'beard cut', '200', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 06:41:02'),
(53, '2021-08-27', 'mwangi', 'kid cut', '200', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 06:41:02'),
(54, '2021-08-27', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 06:41:02'),
(55, '2021-08-27', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(56, '2021-08-27', 'james', 'hair colour', '600', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(57, '2021-08-27', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(58, '2021-08-27', 'james', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(59, '2021-08-27', 'james', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(60, '2021-08-27', 'james', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(61, '2021-08-27', 'james', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(62, '2021-08-27', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(63, '2021-08-28', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(64, '2021-08-28', 'mwangi', 'kid cut', '200', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 17:45:26'),
(65, '2021-08-28', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(66, '2021-08-28', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(67, '2021-08-28', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 17:45:26'),
(68, '2021-08-28', 'njogu', 'kid cut', '200', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(69, '2021-08-28', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(70, '2021-08-28', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 17:45:26'),
(71, '2021-08-28', 'james', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(72, '2021-08-28', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(73, '2021-08-28', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(74, '2021-08-28', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-28 17:45:26'),
(75, '2021-08-28', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 17:45:26'),
(76, '2021-08-28', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-28 17:45:26'),
(77, '2021-08-28', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(78, '2021-08-28', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(79, '2021-08-28', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(80, '2021-08-29', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-29 17:02:30'),
(81, '2021-08-29', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(82, '2021-08-29', 'james', 'kid cut', '200', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-29 17:02:30'),
(83, '2021-08-29', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(84, '2021-08-29', 'njogu', 'hair cut', '300', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(85, '2021-08-29', 'mwangi', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(86, '2021-08-29', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(87, '2021-08-29', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(88, '2021-08-29', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-29 17:02:30'),
(89, '2021-08-29', 'mwangi', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(90, '2021-08-29', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(91, '2021-08-29', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(92, '2021-08-29', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-29 17:02:30'),
(93, '2021-08-29', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(94, '2021-08-29', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(95, '2021-08-30', 'mwangi', 'beard cut', '200', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(96, '2021-08-30', 'njogu', 'kid cut', '300', 'Cash', 'AKAIPLAZA', 'liz', 1, '2021-08-30 16:29:03'),
(97, '2021-08-30', 'njogu', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-30 16:29:03'),
(98, '2021-08-30', 'njogu', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-30 16:29:03'),
(99, '2021-08-30', 'james', 'kid cut', '200', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:33:54'),
(100, '2021-08-30', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-30 16:29:03'),
(101, '2021-08-30', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(102, '2021-08-30', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(103, '2021-08-30', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-30 16:29:03'),
(104, '2021-08-30', 'mwangi', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'mary', 1, '2021-08-30 16:29:03'),
(105, '2021-08-30', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-30 16:29:03'),
(106, '2021-08-30', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(107, '2021-08-30', 'njogu', 'hair colour', '1000', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(108, '2021-08-30', 'njogu', 'hair cut', '300', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-30 16:29:03'),
(109, '2021-08-31', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-31 17:04:55'),
(110, '2021-08-31', 'james', 'hair cut', '300', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-31 17:04:55'),
(111, '2021-08-31', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(112, '2021-08-31', 'mwangi', 'hair cut', '300', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(113, '2021-08-31', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(114, '2021-08-31', 'njogu', 'hair cut', '300', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(115, '2021-08-31', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(116, '2021-08-31', 'njogu', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(117, '2021-08-31', 'mwangi', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-31 17:04:55'),
(118, '2021-08-31', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(119, '2021-08-31', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-31 17:04:55'),
(120, '2021-08-31', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(121, '2021-08-31', 'james', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-31 17:04:55'),
(122, '2021-09-02', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(123, '2021-09-02', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-09-02 16:44:17'),
(124, '2021-09-02', 'njogu', 'hair cut', '400', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(125, '2021-09-02', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-09-02 16:44:17'),
(126, '2021-09-02', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(127, '2021-09-02', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-09-02 16:44:17'),
(128, '2021-09-02', 'mwangi', 'hair colour', '600', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-09-02 16:44:17'),
(129, '2021-09-02', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-09-02 16:44:17'),
(130, '2021-09-02', 'mwangi', 'hair colour', '800', 'Cash', 'AKAIPLAZA', 'carol', 1, '2021-09-02 16:44:17'),
(131, '2021-09-02', 'mwangi', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(132, '2021-09-02', 'njogu', 'hair cut', '400', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-09-02 16:44:17');

-- --------------------------------------------------------

--
-- Table structure for table `regdetails`
--

CREATE TABLE `regdetails` (
  `id` int(11) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL,
  `idNo` int(11) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `Category` varchar(40) NOT NULL,
  `password` varchar(80) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beauty`
--
ALTER TABLE `beauty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `haircut`
--
ALTER TABLE `haircut`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regdetails`
--
ALTER TABLE `regdetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idNo` (`idNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `beauty`
--
ALTER TABLE `beauty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `haircut`
--
ALTER TABLE `haircut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;

--
-- AUTO_INCREMENT for table `regdetails`
--
ALTER TABLE `regdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
