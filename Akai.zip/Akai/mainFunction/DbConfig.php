<?php
Class DbConfig{
private $_host="localhost";
private $_userName="root";
private $_password="";
private $_database="idealbarber";

protected $connection;

public function __Construct(){

if(!isset($this->connection)){
$this->connection = new mysqli($this->_host,$this->_userName,$this->_password,$this->_database);

if(!$this->connection){
echo'cannot connect to the database server';
exit;
}
}
return $this->connection;
}
}
?>