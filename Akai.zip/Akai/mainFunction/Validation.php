<?php
Class Validation{
public function check_empty($data,$fields){
$msg=null;
forEach($fields as $value){
if(empty($data[$value])){
$msg.="$value field is empty</br>";
}
}
return $msg;
}
public function is_Id_Valid($IdNo){
if(preg_match("/^[0-9]+$/",$IdNo)){
return true;
}
return false;
}
public function is_email_valid($email){
if(filter_var ($email, FILTER_VALIDATE_EMAIL)){
return true;
}
return false;
}
}
?>