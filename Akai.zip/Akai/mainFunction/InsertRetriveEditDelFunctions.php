<?php
include_once 'DbConfig.php';
Class InsertRetriveEditDelFunctions extends DbConfig{
public function __Construct(){
parent ::__Construct();
}
public function getData($query){
$result= $this->connection->query($query);
if($result==false){
return false;
}
$rows = array();
while($row =$result->fetch_assoc()){
$rows[]=$row;

}
return $rows;
}
public function excute($query){
$result=$this->connection->query($query);
if($result==false){
echo"Error: Cannot Excute the Command";
return false;
}
else{
return true;
}
}
public function delete($id,$table){
$query="DELETE FROM employeesalarydetails WHERE IdNumber=$id";
$result = $this->connection->query($query);
if($result==false){
echo'Error: cannot Delete id'.$id.'from the table'.$table.'';
return false;
}
else{
return true;
}
}
public function checkAvailability(){
$query= "SELECT * FROM `regdetails`";
$result = $this->connection->query($query);
if($result==false){
echo'Error: cannot Delete idfrom the table';
return false;
}
else{
return true;
}
}
public function escape_String($value){
return $this->connection->real_escape_String($value);
}
}
?>