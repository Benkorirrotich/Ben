<tr>
    <th bgcolor="#999999" scope="row"><div align="center" class="style13">
      <div align="left">Event End Time </div>
    </div></th>
    <td width="265"><input name="edate" type="date" id="from_date">
    <input name="etime" type="time" id="from_time"></td>

    </tr>