		<?php
					if($_POST){
						require "includes/connection.php";
			//GETTING values

					//$transaction= $_POST['transaction'];
			
			
			
			

		if(mysqli_query($con,"UPDATE `haircut` SET availability=1"));
		{
	echo"<script>alert(Data Updated successfuly')</script>";
	echo"<script>location.href='manage_haircut.php'</script>";
		
//else{
	//echo"<script>alert('ERROR ! Could not Update details , try again later')</script>";
	//echo"<script>location.href='add.php'</script>";
//}

		}			
					
				}
				
					


		
		
		  ?>
