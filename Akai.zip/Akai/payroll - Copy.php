

<script>

   
    function calc()
    {
		form=document.getElementById("form1");
		 sal=form.sal.value;
        sal=parseFloat(sal);
		if (sal <=5999){
	
      form.nssf.value=(360);
     form.nhif.value=(150);
      form.payee.value=(sal*10/100);


      d=parseFloat(form.nssf.value);
	  n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h));
		}
	else if(sal >=6000 && sal <=7999){
	  form.nssf.value=(360);
	   form.nhif.value=(300);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
	else if(sal >=8000 && sal <=11999){
	  form.nssf.value=(360);
	   form.nhif.value=(400);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=12000 && sal <=14999){
	  form.nssf.value=(360);
	   form.nhif.value=(500);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=15000 && sal <=19999){
	  form.nssf.value=(360);
	   form.nhif.value=(600);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
		else if(sal >=20000 && sal <=24999){
	  form.nssf.value=(360);
	   form.nhif.value=(750);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=25000 && sal <=29999){
	  form.nssf.value=(360);
	   form.nhif.value=(850);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=30000 && sal <=34999){
	  form.nssf.value=(360);
	   form.nhif.value=(900);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=35000 && sal <=39999){
	  form.nssf.value=(360);
	   form.nhif.value=(950);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=40000 && sal <=44999){
	  form.nssf.value=(360);
	   form.nhif.value=(1000);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=45000 && sal <=49999){
	  form.nssf.value=(360);
	   form.nhif.value=(1100);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=50000 && sal <=59999){
	  form.nssf.value=(360);
	   form.nhif.value=(1200);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=60000 && sal <=69999){
	  form.nssf.value=(360);
	   form.nhif.value=(1300);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=70000 && sal <=79999){
	  form.nssf.value=(360);
	   form.nhif.value=(1400);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=80000 && sal <=89999){
	  form.nssf.value=(360);
	   form.nhif.value=(1500);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=90000 && sal <=99999){
	  form.nssf.value=(360);
	   form.nhif.value=(1000);
      form.payee.value=(sal*10/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
			else if(sal >=100000){
	  form.nssf.value=(360);
	   form.nhif.value=(1700);
      form.payee.value=(sal*25/100);
	  
	  
      d=parseFloat(form.nssf.value);
	   n=parseFloat(form.nhif.value);
      h=parseFloat(form.payee.value);
      
      form.ns.value=parseFloat(sal-(d+h+n));
    }
	}

</script>
	<html>
<head>
    <title>Accountant page </title>
<script type="text/javascript" src="javaScript/javascript.js"></script>
</head>

<body>
<form id="form1" method="post" action="">
<fieldset>
<legend><em><h1 style="color:red">Payroll Calculator</em></h1></legend>
<table  width="95%" border='1' cellpadding='0'>
<form method="POST" action="">
<tr><td>Gross Salary:</td><td>
<input type="text" size="20" name="sal" placeholder="Enter amount eg.10000" required /><td></tr>
<tr><td>NSSF:</td><td>
<input type="text" size="20" name="nssf" required readOnly /><td></tr>
<tr><td>NHIF:</td><td>
<input type="text" size="20" name="nhif" required readOnly /><td></tr>
<tr><td>PAYEE:</td><td>
<input type="text" size="20" name="payee" required readOnly /><td></tr>

<tr><td>NET SALARY:</td><td>
<input type="text" size="20" name="ns" required readOnly /><td></tr>
<tr><td><input type="button" name="btn" value="Calculate" onclick="calc()"><input type="submit" name="submit1" value="submit"><input type="reset" value="clear"></td></tr>
</form>
</table>

</body>
</html>