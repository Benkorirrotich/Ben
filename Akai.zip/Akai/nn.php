
	 	    	  	  	    	    	       	   	     	    	    	 <div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 26<sup>th</sup>, Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
	    
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>Deportivo Alaves	-	Elche CF</td></td><td class="green">HTFT X/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Boston United	-	York City</td><td class="green">CS (2:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Belgium</td><td>RE Mouscron	-	Standard Liege</td></td><td class="green">2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Turkey</td><td>Adanaspor	-	Adıyamanspor</td></td><td class="green">CS (2:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    
	    
	    	   	    	       	    	    	   <div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 25<sup>th</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

	   	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Romania</td><td>CFR Cluj	-	Sepsi OSK</td><td>CS(2:0)</td><td><strong style="color:green;">Won</strong></td></tr>
 <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Sweden</td><td>Enkopings SK	-	IFK Lidingo</td><td>GG</td><td><strong style="color:green;">Won</strong></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Germany</td><td>MSV Duisburg	-	Kaiserslautern</td><td>CS(1:1)</td><td><strong style="color:green;">Won</strong></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Norway</td><td>IL Hodd	-	Valerenga 2</td><td class="green">HTFT 1/1</td><td><strong style="color:green;">Won</strong></td></tr>
		
	</tbody>
</table>
</div>    

	    
		    	    	       	              <div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 24<sup>th</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

	   	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Sweden</td><td>IF Elfsborg	-	Sirius IK</td><td>CS(3:0)</td><td><strong style="color:green;">Won</strong></td></tr>
 <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Fiorentina	-	Cagliari Calcio</td><td>1</td><td><strong style="color:green;">Won</strong></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">France</td><td>FC Lorient	- Bordeaux</td><td>CS(1:1)</td><td><strong style="color:green;">Won</strong></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Manchester United	-	Liverpool</td><td class="green">HTFT 2/2</td><td><strong style="color:green;">Won</strong></td></tr>
		
	</tbody>
</table>
	    
</div>  	   
	        	    	    
	    
	    
	    	    	    	       	    	    	        <div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 23<sup>rd</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

       
       <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Spain</td><td>Cadiz CF	0-2	Deportivo Alaves</td><td>CS (0:2)</td><td><span style="color:green;">Won</span></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Romania</td><td>FC Voluntari	-	Arges Pitesti</td><td>HTFT X/2</td><td><span style="color:green;">Won</span></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>England</td><td>Burton Albion	-	Oxford United</td><td>GG</td><td><span style="color:green;">Won</span></td></tr>
	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>England</td><td>West Bromwich	-	Bristol City</td><td class="green">CS(3:0)</td><td class="green"><span style="color:green;">Won</span></td></tr>	
	</tbody>
</table>
</div>
	    
	    	    	    	 	    	   	
	  		    	       	    	    	       		<div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 22<sup>nd</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Turkey</td><td>Ankaragucu	-	Manisa FK</td></td><td class="green">CS(2:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">France</td><td>Annecy FC	-	SO Cholet</td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Arsenal	-	Aston Villa</td></td><td class="green">CS(3:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Netherlands</td><td>Jong Utrecht	-	TOP Oss</td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
</div>    

	 
	 
	 	    	    	            		<div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 21<sup>th</sup>, Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPA</td><td>Rangers FC	-	Brondby IF</td></td><td class="green">CS(2:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>UD Almeria	-	Real Sociedad B</td><td class="green">GG</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Sweden</td><td>GAIS	-	AFC Eskilstuna</td></td><td class="green">CS(2:3)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>CD Mirandes	-	Girona FC</td></td><td class="green">HTFT 2/2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
	    
</div>
	  
	 
	 	    	    
	    	    	    	    	       	<div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 20<sup>st</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUEFA</td><td>BSC Young Boys	-	Villarreal CF</td></td><td class="green">CS(1:4)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Norway</td><td>Kongsvinger	-	Asker Fotball</td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Preston NE	-	Coventry City</td></td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Swansea City	-	West Bromwich</td></td><td class="green">CS(2:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
</div>
	    
	 
	 
	 	    		    	    	  	    	 		  		<div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 19<sup>th</sup>, Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

       <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>FC Cartagena	-	Sporting Gijon</td></td><td class="green">CS (1:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUEFA</td><td>Paris St. Germain	-	RB Leipzig</td><td class="green">HTFT X/1</td><td class="red"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Sweden</td><td>Falkenbergs FF	-	Helsingborg</td></td><td class="green">2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUEFA</td><td>AFC Ajax	-	Borussia Dortmund</td><td class="green">(4:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
</tbody>
</table>
</div>     	    
	 	    	    	    	    	<div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 18<sup>th</sup>, Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
    	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

        <tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Netherlands</td><td>FC Volendam	-	NAC Breda</td><td>CS(1:0)</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Turkey</td><td>Hatayspor	-	Gazisehir Gaziantep</td><td>HTFT 1/1</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Netherlands</td><td>Jong AZ Alkmaar	-	Jong Ajax</td><td>CS(1:1) </td><td><strong style="color:green;">Won</strong></td></tr>	   
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Spain</td><td>Deportivo Alaves	-	Real Betis<td>2</td><td><strong style="color:green;">Won</strong></td></tr>
			</tbody>
</table>
</div>
	    

	 	    
	    	  	    	        	    		    	    	    		       	<div><h2 style="text-align: center;font-size: large;background-color:darkblue;color:white;padding:20px;"><strong>Tips For 17<sup>th</sup>, Oct,2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Denmark</td><td>FC Nordsjælland	-	FC Midtjylland</td></td><td class="green">GG</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>Villarreal CF	-	CA Osasuna</td><td class="green">CS(1:2)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">France</td><td>Troyes AC	-	OGC Nice</td></td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">France</td><td>Montpellier HSC	-	RC Lens</td></td><td class="green">CS(1:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    