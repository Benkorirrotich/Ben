
	   	    	       	    	    	   <div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 04<sup>th</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

	   	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Denmark</td><td>Esbjerg fB	-	HB Koge</td><td>CS(2:0)</td><td><strong style="color:green;">Won</strong></td></tr>
 <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Sweden</td><td>Vasalunds IF	1-1	IFK Varnamo</td><td>GG</td><td><strong style="color:green;">Won</strong></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Swansea City U21	-	Ipswich U21</td><td>CS(0:3)</td><td><strong style="color:green;">Won</strong></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Romania</td><td>Clinceni - BOTOSANI</td><td class="green">HTFT 2/X</td><td><strong style="color:green;">Won</strong></td></tr>
		
	</tbody>
</table>
</div> 
   	    
	    
		    	    	       	              <div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 03<sup>rd</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

	   	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Pontedera	-	Virtus Entella</td><td>CS(2:1)</td><td><strong style="color:green;">Won</strong></td></tr>
 <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>Malaga CF	-	CF Fuenlabrada</td><td>1</td><td><strong style="color:green;">Won</strong></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Netherlands</td><td>SC Cambuur	-	Heracles Almelo</td><td>CS(2:1)</td><td><strong style="color:green;">Won</strong></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>FC Bari 1908 -	Monopoli</td><td class="green">HTFT X/1</td><td><strong style="color:green;">Won</strong></td></tr>
		
	</tbody>
</table>
	    
</div>  	   
	        	    


	    	    	    	       	    	    	        <div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 02<sup>nd</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

       
       <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Italy</td><td>Salernitana - GENOA</td><td>CS (1:0)</td><td><span style="color:green;">Won</span></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Netherlands</td><td>RKC Waalwijk	-	Go Ahead Eagles</td><td>HTFT 2/X</td><td><span style="color:green;">Won</span></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Spain</td><td>Mallorca - LEVANTE</td><td>1</td><td><span style="color:green;">Won</span></td></tr>
	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>England</td><td>BOURNEMOUTH v Sheff Utd </td><td class="green">CS(2:1)</td><td class="green"><span style="color:green;">Won</span></td></tr>	
	</tbody>
</table>
</div>

	    	 	    	   	
	  		    	       	    	    	       		<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 01<sup>st</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">France</td><td>Orleans - Bastia  Borgo</td></td><td class="green">CS(4:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Belgium</td><td>KV MECHELEN - Standard Liege</td><td class="green">OV2.5</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Netherlands</td><td>Jong PSV - VENLO</td></td><td class="green">CS(2:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Cagliari Calcio	-	Venezia FC</td><td class="green">HTFT 1/X</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
</div>    

	    	    	            		<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 30<sup>th</sup>, Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPA</td><td>KAA Gent	-	Anorthosis FC</td></td><td class="green">CS(2:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPA</td><td>Real Sociedad	-	AS Monaco</td><td class="green">GG</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Avellino - Catanzaro</td></td><td class="green">CS(0:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPA</td><td>TOTTENHAM v Mura</td></td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
	    
</div>
	  
	    
	    	    	    	    	       	<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 29<sup>st</sup>,Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Norway</td><td>Strommen IF	-	KFUM Oslo</td></td><td class="green">CS(1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Monopoli	-	AZ Picerno</td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUEFA</td><td>Juventus FC	-	Chelsea</td></td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Derby County	-	Reading FC</td></td><td class="green">CS(1:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
</div>
	    
	    
	    		    	    	  	    	 		  		<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 28<sup>th</sup>, Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

       <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Reggiana	-	Carrarese Calcio</td></td><td class="green">CS (3:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Cambridge United	-	Gillingham</td><td class="green">HTFT 2/2</td><td class="red"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Cesena	-	Modena FC</td></td><td class="green">2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Hull City	-	Blackpool</td><td class="green">(1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
</tbody>
</table>
</div>     	    
	    
	    	    	    	    
	    	    	    	<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 27<sup>th</sup>, Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
    	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

        <tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>England</td><td>Crystal Palace v BRIGHTO</td><td>CS(1:1)</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Spain</td><td>CELTA DE VIGO v Granada</td><td>HTFT 1/1</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Turkey</td><td>Trabzonspor	-	Alanyaspor</td><td>CS(1:1) </td><td><strong style="color:green;">Won</strong></td></tr>	   
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Portugal</td><td>Boavista FC	-	GD Estoril<td>GG</td><td><strong style="color:green;">Won</strong></td></tr>
			</tbody>
</table>
</div> 
	  
	  	    	        	    		    	    	    		       	<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 26<sup>th</sup>, Sept,2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>SASSUOLO v Salernitana</td></td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>FC Barcelona	-	Levante UD</td><td class="green">CS(3:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Switzerland</td><td>FC Basel	-	FC Zurich</td></td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Southampton	-	Wolverhampton</td></td><td class="green">CS(0:2)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    
	    	    
	  
	  	  	    	    	       	   	     	    	    	 <div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 25<sup>th</sup>, Aug, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
	    
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Germany</td><td>Ingolstadt	-	Fortuna Dusseldorf</td></td><td class="green">HTFT 2/2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Blackpool	-	Barnsley</td><td class="green">CS (1:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Oxford United	1-1	Gillingham</td></td><td class="green">GG</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Denmark</td><td>VSK Aarhus	-	FC Roskilde</td></td><td class="green">CS (2:2)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    