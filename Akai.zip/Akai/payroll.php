

<script>

   
    function calc()
    {
		form=document.getElementById("form1");
		 sal=form.sal.value;
        sal=parseFloat(sal);
	
      form.nssf.value;
     form.nhif.value;
     


      d=parseFloat(form.nssf.value);
	  n=parseFloat(form.nhif.value);
     
      
      form.ns.value=parseFloat(sal-(d+n));
	
	}

</script>
	<html>
<head>
    <title>Accountant page </title>
<script type="text/javascript" src="javaScript/javascript.js"></script>
</head>

<body>
<form id="form1" method="post" action="">
<fieldset>
<legend><em><h1 style="color:red">Payroll Calculator</em></h1></legend>
<table  width="95%" border='1' cellpadding='0'>
<form method="POST" action="">
<tr><td>Gross Salary:</td><td>
<input type="text" size="20" name="sal" placeholder="Enter amount eg.10000" required /><td></tr>
<tr><td>NSSF:</td><td>
<input type="text" size="20" name="nssf" required /><td></tr>
<tr><td>NHIF:</td><td>
<input type="text" size="20" name="nhif" required  /><td></tr>
<tr><td>PAYEE:</td><td>
<input type="text" size="20" name="payee" required readOnly /><td></tr>

<tr><td>NET SALARY:</td><td>
<input type="text" size="20" name="ns" required readOnly /><td></tr>
<tr><td><input type="button" name="btn" value="Calculate" onclick="calc()"><input type="submit" name="submit1" value="submit"><input type="reset" value="clear"></td></tr>
</form>
</table>

</body>
</html>