<?php
  session_start();
 include "db.php";
if(isset($_POST['submit']))
{
$phonenuber=$_POST['phonenuber'];
$amount=$_POST['amount'];
$Account_no=$_POST['Account_no'];

//$amount = '100'; //Amount to transact 
//$phonenuber = '0707418117'; // Phone number paying
$Account_no = 'zuritips'; // Enter account number optional
$url = 'https://tinypesa.com/api/v1/express/initialize';
$data = array(
    'amount' => $amount,
    'msisdn' => $phonenuber,
    'account_no'=>$Account_no
);
$headers = array(
    'Content-Type: application/x-www-form-urlencoded',
    'ApiKey: Oke5TrnHVnJ' // Replace with your api key
 );
$info = http_build_query($data);

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $info);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
$resp = curl_exec($curl);
$msg_resp = json_decode($resp);

mysqli_query($con,"insert tinypesa (phonenuber,amount,Account_no) 
values ('$phonenuber','$amount','$Account_no')") 
			or die ("Query 1 is inncorrect........");


//echo"Message Sent";
//header("location: home.php"); 
//mysqli_close($con);

if($msg_resp ->success == 'true'){
    echo "WAIT FOR Bettwintips STK POP UP";
}
}
?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
<!--    <link href="images/logo.jpg" rel="shortcut icon"> -->
   
  <!-- core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">  
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
     <!-- End Navbar -->
	  <table  border='1' cellpadding='0'>
      <div class="content">
        <div class="container-fluid">
        <div class="col-md-5 mx-auto">
            <div class="card">
              <div class="card-header card-header-primary">
                
              </div>
			  <link rel="stylesheet" type="text/css" href="styles.css" />
                     <form method="post" action="" class="form-horizontal" enctype="multipart/form-data">
             
 
      <div class="modal-body">
      <div class="row">
      <div class="col-lg-2">
    <label class="pull-right" style="color:skyblue">Mobile Number</label>
  </div>
  <div class="col-lg-10">
	    <input type="text" placeholder="eg.072XXXXXXX" name="phonenuber" class="form-control" required >
</div></div><br>
  <div class="row">
      <div class="col-lg-2">
    <label class="pull-right" style="color:skyblue">Amount</label>
  </div>
  <div class="col-lg-10">
	    <input type="text" placeholder="eg.100" name="amount" class="form-control" required >
</div></div><br>
  <div class="row">
      <div class="col-lg-2">
    <label class="pull-right" style="color:skyblue">Account Number</label>
  </div>
  <div class="col-lg-10">
	    <input type="text" placeholder="Enter your mobile Number as Account Number" name="Account_no" class="form-control" >
</div></div><br>
      </div>
      <div class="modal-footer">
         <a href="home.php" class="btn btn-default">Close</a>
        <input class="btn btn-info wow fadeInDown" name="submit" type="submit" value="Send"/>
      </div>
  
      </form>
            </div>
          </div>
         
          
        </div>
      </div>
	  </html>



