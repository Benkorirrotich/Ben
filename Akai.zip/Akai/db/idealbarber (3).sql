-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 10, 2021 at 03:47 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idealbarber`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `lname`, `username`, `password`, `Regdate`) VALUES
(1, 'Ben', 'Korir', 'Ben', 'Ben@ben1', '2021-08-20 10:14:11'),
(3, 'Purity', 'Purity', 'Purity', 'Purity1', '2021-11-01 10:24:21'),
(4, 'Silas ', 'Laimaru', 'Laimaru', 'Laimaru1', '2021-11-01 10:25:10');

-- --------------------------------------------------------

--
-- Table structure for table `beauty`
--

CREATE TABLE `beauty` (
  `id` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `timeIn` varchar(200) NOT NULL,
  `timeout` varchar(200) NOT NULL,
  `timetaken` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `contact`, `date`) VALUES
(2, 'Benard Korir', '0707418117', '2021-10-31 08:29:57'),
(3, 'Mercy', '0707418117', '2021-11-03 14:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `haircut`
--

CREATE TABLE `haircut` (
  `id` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `hwash` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `offduty`
--

CREATE TABLE `offduty` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `regdetails`
--

CREATE TABLE `regdetails` (
  `id` int(11) NOT NULL,
  `fName` varchar(50) NOT NULL,
  `lName` varchar(50) NOT NULL,
  `idNo` int(11) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `Category` varchar(40) NOT NULL,
  `password` varchar(80) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regdetails`
--

INSERT INTO `regdetails` (`id`, `fName`, `lName`, `idNo`, `phoneNumber`, `Category`, `password`, `date`) VALUES
(8, 'Benard', 'Korir', 29907186, '0707418117', 'admin', 'Ben123', '2021-08-10 14:46:31');

-- --------------------------------------------------------

--
-- Table structure for table `tinypesa`
--

CREATE TABLE `tinypesa` (
  `id` int(11) NOT NULL,
  `phonenuber` varchar(50) NOT NULL,
  `amount` varchar(12) NOT NULL,
  `Account_no` varchar(12) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tinypesa`
--

INSERT INTO `tinypesa` (`id`, `phonenuber`, `amount`, `Account_no`, `date`) VALUES
(1, '07xxxxxxx', 'eg.100', 'Enter accoun', '2021-10-04 08:01:52'),
(2, '07xxxxxxx', 'eg.', 'Enter accoun', '2021-10-04 08:07:41'),
(3, '07xxxxxxx', 'eg.', 'Enter accoun', '2021-10-04 08:09:18'),
(4, '0707418117', '1', 'ii', '2021-10-04 08:22:13'),
(5, '0707418117', '1', 'ee', '2021-10-04 08:25:51'),
(6, '0707418117', '1', 'yy', '2021-10-04 08:54:26'),
(7, '0707418117', '3000', 'zuritips', '2021-10-04 10:11:13'),
(8, '0707418117', '1', 'zuritips', '2021-10-04 10:12:02'),
(9, '0714246040', '3000', 'zuritips', '2021-10-09 16:50:57'),
(10, '0714126169', '3000', 'zuritips', '2021-10-09 16:51:52'),
(11, '254714126169', '1', 'zuritips', '2021-10-09 17:01:35'),
(12, '254707418117', '1', 'IdealBarber', '2021-10-10 00:22:29'),
(13, '0707418117', '1', 'zuritips', '2021-10-10 00:27:45'),
(14, '0707418117', '1', 'zuritips', '2021-10-10 00:30:06'),
(15, '0707418117', '3000', 'zuritips', '2021-10-10 00:37:27'),
(16, '254707418117', '800', 'zuritips', '2021-10-10 00:37:48'),
(17, '0707418117', '3000', 'zuritips', '2021-10-10 00:40:07'),
(18, '0707418117', '3000', 'zuritips', '2021-10-10 00:41:49'),
(19, '0707418117', '3000', 'zuritips', '2021-10-10 00:44:29'),
(20, '0707418117', '800', 'zuritips', '2021-10-10 00:44:40'),
(21, '0707418117', '1', 'zuritips', '2021-10-10 00:46:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beauty`
--
ALTER TABLE `beauty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `haircut`
--
ALTER TABLE `haircut`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offduty`
--
ALTER TABLE `offduty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regdetails`
--
ALTER TABLE `regdetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idNo` (`idNo`);

--
-- Indexes for table `tinypesa`
--
ALTER TABLE `tinypesa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `beauty`
--
ALTER TABLE `beauty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `haircut`
--
ALTER TABLE `haircut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `offduty`
--
ALTER TABLE `offduty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `regdetails`
--
ALTER TABLE `regdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tinypesa`
--
ALTER TABLE `tinypesa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
