-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2021 at 03:45 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idealbarber`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fname`, `lname`, `username`, `password`, `Regdate`) VALUES
(1, 'Ben', 'Korir', 'Ben', 'Ben@ben1', '2021-08-20 10:14:11'),
(3, 'Purity', 'Purity', 'Purity', 'Purity1', '2021-11-01 10:24:21'),
(4, 'Silas ', 'Laimaru', 'Laimaru', 'Laimaru1', '2021-11-01 10:25:10');

-- --------------------------------------------------------

--
-- Table structure for table `beauty`
--

CREATE TABLE `beauty` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `commission` varchar(50) NOT NULL,
  `tcommission` varchar(50) NOT NULL,
  `headwash` varchar(50) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `timeIn` varchar(200) NOT NULL,
  `timeout` varchar(200) NOT NULL,
  `timetaken` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `sales` varchar(50) NOT NULL,
  `advance` varchar(50) NOT NULL,
  `Others` varchar(50) NOT NULL,
  `tsales` varchar(50) NOT NULL,
  `remarks` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL DEFAULT current_timestamp(),
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `haircut`
--

CREATE TABLE `haircut` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `commission` varchar(50) NOT NULL,
  `tcommission` varchar(50) NOT NULL,
  `hwash` varchar(50) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `haircut1`
--

CREATE TABLE `haircut1` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `commission` varchar(200) NOT NULL,
  `tcommission` varchar(200) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `hwash` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `haircut1`
--

INSERT INTO `haircut1` (`id`, `date`, `name`, `service`, `amount`, `commission`, `tcommission`, `mode`, `center`, `hwash`, `availability`, `Regdate`) VALUES
(11, '2021-08-23 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(12, '2021-08-23 00:00:00', 'njogu', 'beard cut', '200', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-24 05:59:28'),
(13, '2021-08-23 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-24 05:59:28'),
(14, '2021-08-23 00:00:00', 'njogu', 'hair colour', '600', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-24 05:59:28'),
(15, '2021-08-23 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-24 05:59:28'),
(16, '2021-08-23 00:00:00', 'njogu', 'beard cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-24 05:59:28'),
(17, '2021-08-23 00:00:00', 'njogu', 'hair colour', '300', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-24 05:59:28'),
(18, '2021-08-23 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-24 05:59:28'),
(19, '2021-08-23 00:00:00', 'mwangi', 'beard cut', '200', '', '', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-24 05:59:28'),
(20, '2021-08-23 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-24 05:59:28'),
(21, '2021-08-23 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(22, '2021-08-23 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(23, '2021-08-23 00:00:00', 'njogu', 'hair colour', '1000', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-24 05:59:28'),
(24, '2021-08-23 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-24 05:59:28'),
(25, '2021-08-24 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 06:36:21'),
(26, '2021-08-24 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-26 06:36:21'),
(27, '2021-08-24 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 06:36:21'),
(28, '2021-08-24 00:00:00', 'njogu', 'beard cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-26 06:36:21'),
(29, '2021-08-24 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly ', 1, '2021-08-26 06:36:21'),
(30, '2021-08-24 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-26 06:36:21'),
(31, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 18:20:45'),
(32, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'mary', 1, '2021-08-26 18:20:45'),
(33, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-26 18:20:45'),
(34, '2021-08-26 00:00:00', 'njogu', 'hair colour', '600', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(35, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-26 18:20:45'),
(36, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-26 18:20:45'),
(37, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-26 18:20:45'),
(38, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', '4', 1, '2021-08-26 18:20:45'),
(39, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(40, '2021-08-26 00:00:00', 'fredy', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(41, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-26 18:20:45'),
(42, '2021-08-26 00:00:00', 'njogu', 'hair cut', '300', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-26 18:20:45'),
(43, '2021-08-26 00:00:00', 'njogu', 'hair cut', '300', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-26 18:20:45'),
(44, '2021-08-26 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-26 18:36:27'),
(45, '2021-08-27 00:00:00', 'njogu', 'kid cut', '250', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-28 06:41:02'),
(46, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 06:41:02'),
(47, '2021-08-27 00:00:00', 'njogu', 'beard cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-28 06:41:02'),
(48, '2021-08-27 00:00:00', 'njogu', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(49, '2021-08-27 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(50, '2021-08-27 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 06:41:02'),
(51, '2021-08-27 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-28 06:41:02'),
(52, '2021-08-27 00:00:00', 'mwangi', 'beard cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 06:41:02'),
(53, '2021-08-27 00:00:00', 'mwangi', 'kid cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 06:41:02'),
(54, '2021-08-27 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 06:41:02'),
(55, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(56, '2021-08-27 00:00:00', 'james', 'hair colour', '600', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(57, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(58, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(59, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(60, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(61, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 06:41:02'),
(62, '2021-08-27 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 06:41:02'),
(63, '2021-08-28 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(64, '2021-08-28 00:00:00', 'mwangi', 'kid cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-28 17:45:26'),
(65, '2021-08-28 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(66, '2021-08-28 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(67, '2021-08-28 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 17:45:26'),
(68, '2021-08-28 00:00:00', 'njogu', 'kid cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(69, '2021-08-28 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(70, '2021-08-28 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 17:45:26'),
(71, '2021-08-28 00:00:00', 'james', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(72, '2021-08-28 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(73, '2021-08-28 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(74, '2021-08-28 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-28 17:45:26'),
(75, '2021-08-28 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-28 17:45:26'),
(76, '2021-08-28 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'mary', 1, '2021-08-28 17:45:26'),
(77, '2021-08-28 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(78, '2021-08-28 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-28 17:45:26'),
(79, '2021-08-28 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-28 17:45:26'),
(80, '2021-08-29 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-29 17:02:30'),
(81, '2021-08-29 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(82, '2021-08-29 00:00:00', 'james', 'kid cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-29 17:02:30'),
(83, '2021-08-29 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(84, '2021-08-29 00:00:00', 'njogu', 'hair cut', '300', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(85, '2021-08-29 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(86, '2021-08-29 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(87, '2021-08-29 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(88, '2021-08-29 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-29 17:02:30'),
(89, '2021-08-29 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-08-29 17:02:30'),
(90, '2021-08-29 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(91, '2021-08-29 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(92, '2021-08-29 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-29 17:02:30'),
(93, '2021-08-29 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(94, '2021-08-29 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-29 17:02:30'),
(95, '2021-08-30 00:00:00', 'mwangi', 'beard cut', '200', '', '', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(96, '2021-08-30 00:00:00', 'njogu', 'kid cut', '300', '', '', 'Cash', 'AKAIPLAZA', 'liz', 1, '2021-08-30 16:29:03'),
(97, '2021-08-30 00:00:00', 'njogu', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-30 16:29:03'),
(98, '2021-08-30 00:00:00', 'njogu', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'shiru', 1, '2021-08-30 16:29:03'),
(99, '2021-08-30 00:00:00', 'james', 'kid cut', '200', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:33:54'),
(100, '2021-08-30 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-30 16:29:03'),
(101, '2021-08-30 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(102, '2021-08-30 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(103, '2021-08-30 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-08-30 16:29:03'),
(104, '2021-08-30 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'mary', 1, '2021-08-30 16:29:03'),
(105, '2021-08-30 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-30 16:29:03'),
(106, '2021-08-30 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(107, '2021-08-30 00:00:00', 'njogu', 'hair colour', '1000', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-08-30 16:29:03'),
(108, '2021-08-30 00:00:00', 'njogu', 'hair cut', '300', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-30 16:29:03'),
(109, '2021-08-31 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-31 17:04:55'),
(110, '2021-08-31 00:00:00', 'james', 'hair cut', '300', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-08-31 17:04:55'),
(111, '2021-08-31 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(112, '2021-08-31 00:00:00', 'mwangi', 'hair cut', '300', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(113, '2021-08-31 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(114, '2021-08-31 00:00:00', 'njogu', 'hair cut', '300', '', '', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(115, '2021-08-31 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(116, '2021-08-31 00:00:00', 'njogu', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(117, '2021-08-31 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'damaris', 1, '2021-08-31 17:04:55'),
(118, '2021-08-31 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-08-31 17:04:55'),
(119, '2021-08-31 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-31 17:04:55'),
(120, '2021-08-31 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'shiru', 1, '2021-08-31 17:04:55'),
(121, '2021-08-31 00:00:00', 'james', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'brenda', 1, '2021-08-31 17:04:55'),
(122, '2021-09-02 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(123, '2021-09-02 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-09-02 16:44:17'),
(124, '2021-09-02 00:00:00', 'njogu', 'hair cut', '400', '', '', 'Cash', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(125, '2021-09-02 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-09-02 16:44:17'),
(126, '2021-09-02 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(127, '2021-09-02 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-09-02 16:44:17'),
(128, '2021-09-02 00:00:00', 'mwangi', 'hair colour', '600', '', '', 'MPESA', 'AKAIPLAZA', 'damaris', 1, '2021-09-02 16:44:17'),
(129, '2021-09-02 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'carol', 1, '2021-09-02 16:44:17'),
(130, '2021-09-02 00:00:00', 'mwangi', 'hair colour', '800', '', '', 'Cash', 'AKAIPLAZA', 'carol', 1, '2021-09-02 16:44:17'),
(131, '2021-09-02 00:00:00', 'mwangi', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'nelly', 1, '2021-09-02 16:44:17'),
(132, '2021-09-02 00:00:00', 'njogu', 'hair cut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'liz', 1, '2021-09-02 16:44:17'),
(133, '2021-10-31 00:00:00', 'Benard Korir', 'Haircut', '400', '', '', 'MPESA', 'AKAIPLAZA', 'Nelly', 0, '2021-10-31 08:12:28'),
(134, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Nelly', 0, '2021-11-18 11:17:14'),
(135, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Nelly', 0, '2021-11-18 11:18:11'),
(136, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Nelly', 0, '2021-11-18 11:20:35'),
(137, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Nelly', 0, '2021-11-18 11:34:07'),
(138, '2021-11-18 12:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Nelly', 0, '2021-11-18 11:34:41'),
(139, '2021-11-18 12:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Nelly', 0, '2021-11-18 11:35:09'),
(140, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Mary', 0, '2021-11-18 11:46:31'),
(141, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Mary', 0, '2021-11-18 11:48:05'),
(142, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Carlo', 0, '2021-11-18 11:49:36'),
(143, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '', '', 'MPESA', 'AKAIPLAZA', 'Carlo', 0, '2021-11-18 11:50:42');

-- --------------------------------------------------------

--
-- Table structure for table `offduty`
--

CREATE TABLE `offduty` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beauty`
--
ALTER TABLE `beauty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `haircut`
--
ALTER TABLE `haircut`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `haircut1`
--
ALTER TABLE `haircut1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offduty`
--
ALTER TABLE `offduty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `beauty`
--
ALTER TABLE `beauty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `haircut`
--
ALTER TABLE `haircut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `haircut1`
--
ALTER TABLE `haircut1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `offduty`
--
ALTER TABLE `offduty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
