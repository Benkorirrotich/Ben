-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2021 at 01:49 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idealbarber`
--

-- --------------------------------------------------------

--
-- Table structure for table `haircut`
--

CREATE TABLE `haircut` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `service` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `commission` varchar(50) NOT NULL,
  `tcommission` varchar(50) NOT NULL,
  `headwash` varchar(50) NOT NULL,
  `mode` varchar(200) NOT NULL,
  `center` varchar(200) NOT NULL,
  `timeIn` varchar(200) NOT NULL,
  `timeout` varchar(200) NOT NULL,
  `timetaken` varchar(200) NOT NULL,
  `availability` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `Regdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `haircut`
--

INSERT INTO `haircut` (`id`, `date`, `name`, `service`, `amount`, `commission`, `tcommission`, `headwash`, `mode`, `center`, `timeIn`, `timeout`, `timetaken`, `availability`, `status`, `Regdate`) VALUES
(25, '2021-11-17 00:00:00', 'Mercy', 'Massage', '3000', '', '', '', 'MPESA', 'AKAIPLAZA', '13:39', '13:39', '2hrs', 1, 0, '2021-11-18 09:01:14'),
(26, '2021-11-17 00:00:00', 'Mercy', 'Massages', '3000', '1200', '1225', '25', 'MPESA', 'AKAIPLAZA', '13:39', '13:39', '2hrs', 1, 0, '2021-11-18 09:01:14'),
(27, '2021-11-18 00:00:00', 'Benard Korir', 'Massage', '2500', '1000', '1000', '0', 'MPESA', 'AKAIPLAZA', '03:33', '03:33', '1hr', 1, 0, '2021-11-18 09:01:14'),
(28, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '1200', '1225', '25', 'MPESA', 'AKAIPLAZA', '22:22', '10:27', '1hr', 1, 0, '2021-11-18 09:01:14'),
(29, '2021-11-18 00:00:00', 'Mercy', 'Massage', '3000', '1200', '1225', '25', 'MPESA', 'AKAIPLAZA', '04:06', '05:06', '3ominutes', 1, 0, '2021-11-18 09:01:14'),
(30, '2021-11-18 11:09:00', 'Mercy', 'Massages', '3000', '1200', '1225', '25', 'MPESA', 'AKAIPLAZA', '11:10', '14:10', '2hrs', 1, 0, '2021-11-18 09:01:14'),
(31, '2021-11-18 02:44:00', '1', 'Massage', '3000', '1200', 'NaN', '56', 'MPESA', 'AKAIPLAZA', '21:44', '21:44', '30minutes', 0, 0, '2021-11-18 11:45:08'),
(32, '2021-11-18 02:44:00', '1', 'Massage', '3000', '1200', 'NaN', '56', 'MPESA', 'AKAIPLAZA', '21:44', '21:44', '30minutes', 0, 0, '2021-11-18 11:45:09'),
(33, '2021-11-18 02:44:00', '1', 'Massage', '3000', '1200', 'NaN', '56', 'MPESA', 'AKAIPLAZA', '21:44', '21:44', '30minutes', 0, 0, '2021-11-18 11:45:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `haircut`
--
ALTER TABLE `haircut`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `haircut`
--
ALTER TABLE `haircut`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
