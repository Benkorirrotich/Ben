

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e58d93e298c395d1cea40ee/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+254707418117", // WhatsApp number
            call_to_action: "Message us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Bettwintips</title>
<!-- for-mobile-apps -->
 <script>
    window.dataLayer =  window.dataLayer || [];
    var AppAnalytics = {
        data: {
            breakpoint: function() {
                function isMobileMediaQuery() {
                    var mobileMaxWidthMediaQuery = 767;
                    return window.matchMedia ?
                        window.matchMedia('(max-width: ' + mobileMaxWidthMediaQuery + 'px)').matches :
                        Math.max(document.documentElement.clientWidth, window.innerWidth || 0) <= mobileMaxWidthMediaQuery;
                }
                var isMobileView = 0;
                return isMobileView || isMobileMediaQuery() ? 'mobile' : 'desktop';
            },
            stagingEnvironment: ~location.hostname.indexOf('sportpesa.co.ke') ? 'live' : 'staging',
            loggedIn: 'logged in',
            userFTB: 'first time bet'
        },
        pushEvent: function(event) {
            if (1) {
                window.dataLayer.push(event);
            }
        },
        addToBetslipEvent: function(sportEvent, odd) {
            AppAnalytics.pushEvent({
                'event': 'oddAddSuccess',
                'sportEvent': sportEvent,
                'odd': odd
            });
        },
        betPlacedEvent: function(bet) {
            AppAnalytics.pushEvent({
                'event': 'successfulBet',
                'bet': bet
            });
            AppAnalytics.data.userFTB = 'non first time bet';
        }
    };

    AppAnalytics.pushEvent({
        'event': 'allPages',
        'page': {
            'applicationType': 'website',
            'stagingEnvironment': AppAnalytics.data.stagingEnvironment,
            'country': 'kenya',
            'platformType': 'desktop',
            'product': 'sports',
            'currency': 'KSH',
            'breakpoint': AppAnalytics.data.breakpoint()
        },
        'bet': {
            'FTB': AppAnalytics.data.userFTB
        }
    });

    </script>

<!-- Google Tag Manager -->
             
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="keywords" content="Bettwintips Predict Responsive , Smartphone Compatible web template , Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link rel="icon" type="images/x-icon" href="images/download (1)"/>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen">
<link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css'/>
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" property="" />
<link rel="stylesheet" href="css/jquery-ui.css" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/modernizr-2.6.2.min.js"></script>
<!--fonts-->
<link href="//fonts.googleapis.com/css?family=Oswald:300,430,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Federo" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:300,430,700,1000" rel="stylesheet">
<!--//fonts-->
</head>
<body>
<!-- header -->
<div class="banner-top">
			<div class="social-bnr-agileits">
				<ul class="social-icons3">
								<li><a href="#https://web.facebook.com/O" class="fa fa-facebook icon-border facebook"> </a></li>
								<li><a href="#https://twitter.com/" class="fa fa-twitter icon-border twitter"> </a></li>
								
							</ul>
			</div>
			<div class="contact-bnr-w3-agile">
				<ul>
					<li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">INFO@Bettwintips.COM</a></li>
					<li><i class="fa fa-phone" aria-hidden="true"></i>+254707418117</li>
					
				</ul>
			</div>
			<div class="clearfix"></div>
		</div>
	<div class="w3_navigation">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<h1><a class="navbar-brand" href="index.php">Bettwintips</a></h1>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav >
						<ul class="nav navbar-nav menu__list">
							
							<li class="menu__item"><a href="#history" class="menu__link scroll"><strong>Prediction History</strong></a></li>
							<li class="menu__item"><a href="#today" class="menu__link scroll"><strong>Today free Tips</strong></a></li>
							<li class="menu__item"><a href="#odds" class="menu__link scroll"><strong>Our ODDS</strong></a></li>
							<li class="menu__item"><a href="#contact" class="menu__link scroll"><strong>Contact Us</strong></a></li>
						</ul>
					</nav>
				</div>
			</nav>

		</div>
	</div>
<!-- //header -->
		<!-- banner -->
	<div id="home" id="nairobi" class="w3ls-banner">
		<!-- banner-text -->
		<div class="slider">
			<div class="callbacks_container">
				<ul class="rslides callbacks callbacks1" id="slider4">
					<li>
						<div class="w3layouts-banner-top">

							<div class="container">
								<div class="agileits-banner-info">
								
									<h3 style="color:white">We give the best Expert<br> analysed Tips</h3>
										
									<div class="agileits_w3layouts_more menu__item">
				<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal0">Learn More</a>
			</div>
								</div>	
							</div>
						</div>
					</li>
					<li>
						<div class="w3layouts-banner-top w3layouts-banner-top1">
							<div class="container">
								<div class="agileits-banner-info">
								    
								
									<h3 style="color:yellow">Dont Stake Alone <br>Stake With Our Tips!</h3>
									<div class="agileits_w3layouts_more menu__item">
				<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal0">Learn More</a>
			</div>
								</div>	
							</div>
						</div>
					</li>
					<li>
						<div class="w3layouts-banner-top w3layouts-banner-top2">
							<div class="container">
								<div class="agileits-banner-info">
								    
								<h3 style="color:pink">Want Best Expert Analysed Tips?<br>Bettwintips is here for you!</h3>
										
									<div class="agileits_w3layouts_more menu__item">
											<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal0">Learn More</a>
										</div>
								</div>
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="clearfix"> </div>
			<!--banner Slider starts Here-->
		</div>
		    
	</div>	
	<!-- //banner --> 
<!--//Header-->
<!-- //Modal1 -->
<div class="modal fade" id="myModal0" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>TIPS</span></h4>
										
										
										<p> Welcome to Bettwintips to get our expert analysed Tips. Many have won bets through our Tips!
										pay as stated Below and our System(Bettwintips.com) Will send our analysed tips Aoutomaticaly via SMS<ol><li>KSH 100-Daily Odds</li> 
										<li>KSH 280-Betika MidWeek and Grand JackPots</li>
										<li>KSH 300-Sportpesa MidWeek and MeGa JackPots</li>
										<li>KSH 440-Platinum and Fixed Games</li>
										<li>KSH 1500-For Weekly Tips</li>
										</p>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 -->
	<!-- //banner --> 
<!--//Header-->
<!-- //Modal1 -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>TIPS</span></h4>
										
						</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><blink><strong>Our Daily<span>Odds from All Betting Sites</span></strong></blink></h2>
<h4 style="color:yellow;">Join our Daily Odds Membership>></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong>100</strong> for Daily Tips</li>
	
	<li>Enter your M-PESA PIN.</li>
	
	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 -->
	<!-- //banner --> 
<!--//Header-->
<!-- //Modal1 -->
<div class="modal fade" id="jp" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>Tips</span></h4>
										
																</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><blink><strong>Betikajackpot</strong></blink></h2>
<h4 style="color:yellow;">Join our Betika Jackpot Membership>></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong> 280</strong> for Daily Tips</li>
	
	<li>Enter your M-PESA PIN.</li>
	
	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 -->
	<!-- //banner --> 
<!--//Header-->

<div class="modal fade" id="cs" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>Tips</span></h4>
									
											</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><blink><strong>Fixed Matches, Correct Scores, of<b> Over 80+ ODDS</b> With Guranteed Win</strong></blink></h2>
<h4 style="color:yellow;">Fixed matches Membership>></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong> ksh 440</strong> for Fixed Tips And CS</li>
	
	<li>Enter your M-PESA PIN.</li>

	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 --> 
<!-- //Modal1 -->
	<!-- //banner --> 
<!--//Header-->
<div class="modal fade" id="mt" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>Tips</span></h4>
									
											</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><blink><strong>Daily Mozzart Jackpot of<b>10,000,000</b> With Guranteed Win</strong></blink></h2>
<h4 style="color:yellow;">Daily Mozzart Jackpot Membership>></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong> ksh 250</strong> for Mozzart Jackpot</li>
	
	<li>Enter your M-PESA PIN.</li>

	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 -->
<div class="modal fade" id="GT" tabindex="-1" role="dialog">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>BETTWIN<span>TIPS</span></h4>
										<img src="images/Brr.png" alt=" " class="img-responsive">
																</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#008080;color:white;padding:20px;"><blink><strong>Golden Tips 80+</strong></blink></h2>
<h4 style="color:yellow;">Join GOLDEN TIPS, The 4 Winnig Games To Appear Like in Our PRDICTION HISTORY >></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong> 1050</strong> two days Tips</li>
	
	<li>Enter your M-PESA PIN.</li>
	
	<li>'click' Send and wait to receive SMS from our System</li>
	
	<li>Incase Of system Delay TEXT/CALL 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 -->
<!-- //Modal1 --> 

<div class="modal fade" id="spj" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>Tips</span></h4>
									
											</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><blink><strong>Sportpesa Jackpots</strong></blink></h2>
<h4 style="color:yellow;">Sportpesa Midwek & MEGA Jackpot Membership>></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong> ksh 300</strong> for Sportpesa Jackpots</li>
	
	<li>Enter your M-PESA PIN.</li>

	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 --> 
<div class="modal fade" id="max" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>Tips</span></h4>
									
											</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><blink><strong>One Week VIP Subscription With Guranteed Win</strong></blink></h2>
<h4 style="color:yellow;">One Week VIP Membership>></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong> ksh 1500</strong> for One Week VIP Tips</li>
	
	<li>Enter your M-PESA PIN.</li>

	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 --> 

<!-- //Modal1 --> 
<div class="modal fade" id="maxx" tabindex="-1" role="dialog" id="nairobi">
						<!-- Modal1 -->
							<div class="modal-dialog">
							<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4>Bettwin<span>Tips</span></h4>
									
											</div><div style="background-color: #589D3A" >

<h2 id="Basic Members" style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><blink><strong>One Week VVIP Subscription With Guranteed Win</strong></blink></h2>
<h4 style="color:yellow;">One Week VVIP Membership>></h4>
<ol style="color:white;">
	<li>On your Safaricom phone go to the M-PESA menu </li>
	
	<li>Select Lipa Na M-PESA</li>
	
	<li>Select Buy Goods and Services</li>
	
	
	<li>Enter Till Number <strong>5223519</strong>.</li>
	
	<li>Enter Amount<strong> ksh 2500</strong> for One Week VVIP Tips</li>
	
	<li>Enter your M-PESA PIN.</li>

	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	
	</ol>


</div>
										<div class="modal-footer">
                                         <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>

                                            </div>
										 
									</div>
								</div>
							</div>
						</div>
<!-- //Modal1 --> 

<section id="nairobi">

<center><H3 style="color:red;text-align=center">Get Fixed matches Tips for Three Days @KSH950, Till Number 5223519</H3></center><br>
<h2><p style="color:#00FF00" class="lead" align ="center"><a style="color:#FF0000" href ="http://bettwintips.com/" target = "_blank"><strong >Bettwintips</a> offers free football predictions & 
     tips worldwide. It is the best source of well researched football statistics, analysis and predictions. Our VIP tips and Jackpot Analysis are 94.95% SURE. Subscribe to any 
     of the bellow packages and start winning. </strong></p></h2>
        	 </section>
        	 <section id="">

        	 </section>
			 
			     <div id="nairobi" class="plans-section" id="odds">
				   
				 <h3 class="title-w3-agileits title-black-wthree">OUR ODDS AND RATES</h3>
						<div class="priceing-table-main">
				 <div class="col-md-3 price-grid">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							   <div class="price-list">
									<ul>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									
								     </ul>
							</div>
							<div class="price-selet">	
								<h4>Daily Tips</h4>							
								<h3><span>ksh</span>100</h3>						
								<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal">Apply Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 price-grid ">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							<div class="price-list">
									<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="price-selet">
								<h4>Fixed And Platinum Tips</h4>							
								<h3><span>ksh</span>440</h3>					
									<h3><span>Pay 1000</span>After Win</h3>	
								
								<a href="#" class="menu__link" data-toggle="modal" data-target="#cs">Apply Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 price-grid wthree lost">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							<div class="price-list">
							<h4>Fixed Golden 4games Ticket </h4>
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="price-selet">
													
								<h3><span>ksh</span>1050</h3>						
								<a href="#" class="menu__link" data-toggle="modal" data-target="#GT">Apply Now</a>
								
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 price-grid lost">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							<div class="price-list">
							    	<h4>SportPesa Jackpots</h4>	
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="price-selet">
							<h3>EXPIRES ON 25/09 2021</h3>				
								<h3><span>ksh</span>300</h3>
										
								<a href="#" class="menu__link" data-toggle="modal" data-target="#spj">Apply Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 price-grid wthree lost">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							<div class="price-list">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="price-selet">
								<h4>One Week VIP</h4>							
								
                                   <h3><span>ksh</span>1500 for one week</h3>								
								<a href="#" class="menu__link" data-toggle="modal" data-target="#max">Apply Now</a>
							</div>
						</div>
					</div>
				</div>
				
				
			   
				 
			
			
				

				 <div class="col-md-3 price-grid">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							   <div class="price-list">
							       <h4>Betika Jackpots</h4>
									<ul>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star" aria-hidden="true"></i></li>
											<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									
								     </ul>
							</div>
							<div class="price-selet">	
								<h3>EXPIRES ON 25/09 17:30</h3>							
								<h3><span>Each@ ksh</span>280</h3>
							
							<a href="#" class="menu__link" data-toggle="modal" data-target="#jp">Apply Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 price-grid ">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							<div class="price-list">
									<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="price-selet">
								<h4>Mozzart Jackpots</h4>							
								<h3><span>ksh</span>250</h3>						
								<a href="#" class="menu__link" data-toggle="modal" data-target="#mt">Apply Now</a>
								
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-3 price-grid lost">
					<div class="price-block agile">
						
						<div class="price-gd-bottom">
							<div class="price-list">
								<ul>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
									<li><i class="fa fa-star-o" aria-hidden="true"></i></li>
								</ul>
							</div>
							<div class="price-selet">
								<h4>One Week VVIP</h4>							
                                   <h3><span>ksh</span>2500 for one week</h3>								
								<a href="#" class="menu__link" data-toggle="modal" data-target="#maxx">Apply Now</a>
							</div>
						</div>
					</div>
				</div>
				
				
				
			   
				 
				<div class="clearfix"> </div>
			</div>
	
	
		</div>
		
	
					
	<div style="background-color: green;text-align: center" >

<h2 id="Jackpot Tips" style="text-align: center;font-size: large;background-color:#000080;color:white;padding:20px;"><blink><strong>Bettwintips Memberships</strong></strong></blink></h2>
<h4 style="color:yellow;">How to join Bettwintips</h4>
<ol style="color:white;"><strong>

	<li>On your Safaricom phone go to the M-PESA menu </li>
	<li>Select Lipa Na M-PESA</li>
	<li>Select Buy Goods and Services</li>
	    <img src="images/Brr.png" alt=""/>
	<li>Enter Till Number <strong>5223519</strong>.</li>
	<li> Enter the Amount Ksh. 100 for Daily Tips, Ksh. 300 for Sportpesa Midweek & MeGa Jackpots,  Ksh. 280 for Betika Midweek & Grand Jackpots, Ksh.440, Correct Scores & Fixed games,Ksh. 1500 for One Week VIP tips.</li>
	
	<li>Enter your M-PESA PIN.</li>

	<li>Send and wait for SMS receive from Bettwintips Containing Tips in less than 2 minutes</li>
	
	
	<li>Incase you don't Receive message within 2 minutes SMS/call 0707418117</li>
	</strong></ol>


</div>
	
	
<div id="nairobi" id="today"><h2 style="text-align: center;font-size: large;background-color:#000080;color:white;padding:20px;"><strong>Free Tips For 11<sup>th</sup>, OCT. 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Time</td></tr></thead>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Africa</td><td class="green">Mozambique-Cameroon</td><td class="green">2</td><td class="green"><b><span style="color:red;">16:00</span></strong></td></tr>
	
	</tbody>
</table>

</div>


	

	
<section id="nairobi">
    <div><h3 class="title-w3-agileits title-black-wthree" id="pst"  id="noo"><strong>Recent Winning History</strong></h3></div>
    
    	<div><h2 style="text-align: center;font-size: large;background-color:#008B8B;color:white;padding:20px;"><strong>Tips For 09<sup>st</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Japan</td><td>Tokyo Verdy	-	Fagiano Okayama</td></td><td class="green">CS(1:2)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Denmark</td><td>B1908 Amager	-	Ringsted IF</td><td class="green">HTFT 1/X</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Wycombe	-	Gillingham</td></td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Sweden</td><td>Gefle IF	-	Hammarby Talang</td></td><td class="green">CS(2:2)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
</div>
	    
	    
	    		    	    	  	    	 		  		<div><h2 style="text-align: center;font-size: large;background-color:#008B8B;color:white;padding:20px;"><strong>Tips For 08<sup>th</sup>, Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

       <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>Real Valladolid	-	Malaga CF</td></td><td class="green">CS (1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EURO WCQ</td><td>Russia	-	Slovakia</td><td class="green">HTFT 1/1</td><td class="red"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EURO WCQ</td><td>Cyprus	-	Croatia</td></td><td class="green">2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EURO WCQ</td><td>Turkey	-	Norway</td><td class="green">(1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
</tbody>
</table>
</div>     	    
	    
	    	    	    	    
	    
	    	    	    	    	<div><h2 style="text-align: center;font-size: large;background-color:#008B8B;color:white;padding:20px;"><strong>Tips For 07<sup>th</sup>, Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
    	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

        <tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Germany</td><td>Freialdenhoven	-	SV Breinig</td><td>CS(1:0)</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>CAF WCQ</td><td>Tanzania	-	Benin</td><td>HTFT X/2</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>EURO WCQ</td><td>Belgium	-	France</td><td>CS(2:3) </td><td><strong style="color:green;">Won</strong></td></tr>	   
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Norway</td><td>Lillestrom 2	-	Ullensaker/Kisa 2<td>GG</td><td><strong style="color:green;">Won</strong></td></tr>
			</tbody>
</table>
</div>
	    
	    
	    	  	    	        	    		    	    	    		       	<div><h2 style="text-align: center;font-size: large;background-color:#008B8B;color:white;padding:20px;"><strong>Tips For 06<sup>th</sup>, Oct,2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Germany</td><td>ESC Geestemunde	-	SC Borgfeld</td></td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>Lleida Esportiu	-	SD Ejea</td><td class="green">CS(3:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPE WCQ</td><td>Italy	-	Spain</td></td><td class="green">HTFT 2/2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Bournemouth U21	-	Arsenal U21</td></td><td class="green">CS(1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    
	    	    
	    
	    	  	  	    	    	       	   	     	    	    	 <div><h2 style="text-align: center;font-size: large;background-color:#008B8B;color:white;padding:20px;"><strong>Tips For 05<sup>th</sup>, Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
	    
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Finland</td><td>TPV Tampere	-	EPS Espoo</td></td><td class="green">HTFT 2/2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Northampton	-	Walsall FC</td><td class="green">CS (1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Bolton Wanderers	-	Liverpool U21</td></td><td class="green">GG</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Catanzaro	-	Fidelis Andria</td></td><td class="green">CS (3:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    
	        

	   	    	       	    	    	   <div><h2 style="text-align: center;font-size: large;background-color:#008B8B;color:white;padding:20px;"><strong>Tips For 04<sup>th</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

	   	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Denmark</td><td>Esbjerg fB	-	HB Koge</td><td>CS(2:0)</td><td><strong style="color:green;">Won</strong></td></tr>
 <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Sweden</td><td>Vasalunds IF	1-1	IFK Varnamo</td><td>GG</td><td><strong style="color:green;">Won</strong></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Swansea City U21	-	Ipswich U21</td><td>CS(0:3)</td><td><strong style="color:green;">Won</strong></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Romania</td><td>Clinceni - BOTOSANI</td><td class="green">HTFT 2/X</td><td><strong style="color:green;">Won</strong></td></tr>
		
	</tbody>
</table>
</div> 
    
 
   	    
	    
		    	    	       	              <div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 03<sup>rd</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

	   	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Pontedera	-	Virtus Entella</td><td>CS(2:1)</td><td><strong style="color:green;">Won</strong></td></tr>
 <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>Malaga CF	-	CF Fuenlabrada</td><td>1</td><td><strong style="color:green;">Won</strong></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Netherlands</td><td>SC Cambuur	-	Heracles Almelo</td><td>CS(2:1)</td><td><strong style="color:green;">Won</strong></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>FC Bari 1908 -	Monopoli</td><td class="green">HTFT X/1</td><td><strong style="color:green;">Won</strong></td></tr>
		
	</tbody>
</table>
	    
</div>  	   
	        	    


	    	    	    	       	    	    	        <div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 02<sup>nd</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

       
       <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Italy</td><td>Salernitana - GENOA</td><td>CS (1:0)</td><td><span style="color:green;">Won</span></td></tr>
		<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Netherlands</td><td>RKC Waalwijk	-	Go Ahead Eagles</td><td>HTFT 2/X</td><td><span style="color:green;">Won</span></td></tr>
	    <tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>Spain</td><td>Mallorca - LEVANTE</td><td>1</td><td><span style="color:green;">Won</span></td></tr>
	<tr style="text-align: center;color:white;padding:20px;"><td style='text-align:center'>England</td><td>BOURNEMOUTH v Sheff Utd </td><td class="green">CS(2:1)</td><td class="green"><span style="color:green;">Won</span></td></tr>	
	</tbody>
</table>
</div>

	    	 	    	   	
	  		    	       	    	    	       		<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 01<sup>st</sup>,Oct, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">France</td><td>Orleans - Bastia  Borgo</td></td><td class="green">CS(4:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Belgium</td><td>KV MECHELEN - Standard Liege</td><td class="green">OV2.5</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Netherlands</td><td>Jong PSV - VENLO</td></td><td class="green">CS(2:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Cagliari Calcio	-	Venezia FC</td><td class="green">HTFT 1/X</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
</div>    

	    	    	            		<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 30<sup>th</sup>, Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPA</td><td>KAA Gent	-	Anorthosis FC</td></td><td class="green">CS(2:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPA</td><td>Real Sociedad	-	AS Monaco</td><td class="green">GG</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Avellino - Catanzaro</td></td><td class="green">CS(0:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUROPA</td><td>TOTTENHAM v Mura</td></td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
	    
</div>
	  
	    
	    	    	    	    	       	<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 29<sup>st</sup>,Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Norway</td><td>Strommen IF	-	KFUM Oslo</td></td><td class="green">CS(1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Monopoli	-	AZ Picerno</td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">EUEFA</td><td>Juventus FC	-	Chelsea</td></td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Derby County	-	Reading FC</td></td><td class="green">CS(1:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
	</tbody>
</table>
</div>
	    
	    
	    		    	    	  	    	 		  		<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 28<sup>th</sup>, Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

       <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Reggiana	-	Carrarese Calcio</td></td><td class="green">CS (3:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Cambridge United	-	Gillingham</td><td class="green">HTFT 2/2</td><td class="red"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>Cesena	-	Modena FC</td></td><td class="green">2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Hull City	-	Blackpool</td><td class="green">(1:1)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		
</tbody>
</table>
</div>     	    
	    
	    	    	    	    
	    	    	    	<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 27<sup>th</sup>, Sept, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
    	<tbody>
<tr style="text-align: center;color:white;padding:20px;font-weight: bold; background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td><td style="font-weight: bold;background-color:green;">Status</td></tr>

        <tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>England</td><td>Crystal Palace v BRIGHTO</td><td>CS(1:1)</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Spain</td><td>CELTA DE VIGO v Granada</td><td>HTFT 1/1</td><td><strong style="color:green;">Won</strong></td></tr>
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Turkey</td><td>Trabzonspor	-	Alanyaspor</td><td>CS(1:1) </td><td><strong style="color:green;">Won</strong></td></tr>	   
	   	<tr style="text-align: center;font-size: medium;color:white;padding:20px;"><td style='text-align:center'>Portugal</td><td>Boavista FC	-	GD Estoril<td>GG</td><td><strong style="color:green;">Won</strong></td></tr>
			</tbody>
</table>
</div> 
	  
	  	    	        	    		    	    	    		       	<div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 26<sup>th</sup>, Sept,2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Italy</td><td>SASSUOLO v Salernitana</td></td><td class="green">1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Spain</td><td>FC Barcelona	-	Levante UD</td><td class="green">CS(3:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Switzerland</td><td>FC Basel	-	FC Zurich</td></td><td class="green">HTFT 1/1</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Southampton	-	Wolverhampton</td></td><td class="green">CS(0:2)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    
	    	    
	  
	  	  	    	    	       	   	     	    	    	 <div><h2 style="text-align: center;font-size: large;background-color:skyblue;color:white;padding:20px;"><strong>Tips For 25<sup>th</sup>, Aug, 2021</strong></h2>

       <table bgcolor="#182430" border="2" cellpadding="1" style="height: 196px; width: 100%;">
	<tbody>
	    
<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;" style="font-weight: bold;background-color:green;"><td style="font-weight: bold;background-color:green;">country</td><td style="font-weight: bold;background-color:green;">Match</td><td style="font-weight: bold;background-color:green;">Tip</td></td><td style="font-weight: bold;background-color:green;">Status</td></tr></thead>

	   	<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Germany</td><td>Ingolstadt	-	Fortuna Dusseldorf</td></td><td class="green">HTFT 2/2</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Blackpool	-	Barnsley</td><td class="green">CS (1:0)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	    <tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">England</td><td>Oxford United	1-1	Gillingham</td></td><td class="green">GG</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
		<tr style="text-align: center;font-size: large;background-color:#354C5F;color:white;padding:20px;"><td style='text-align:center' class="green">Denmark</td><td>VSK Aarhus	-	FC Roskilde</td></td><td class="green">CS (2:2)</td><td class="green"><b><span style="color:green;">Won</span></strong></td></tr>
	</tbody>
</table>
</div>	    
	    
		
		
	




           

</section id="nairobi">
<!-- contact -->
<section class="contact-w3ls" id="nairobi" id="contact">
	<div class="container">
		<div class="col-lg-6 col-md-6 col-sm-6 contact-w3-agile2" data-aos="flip-left">
			<div class="contact-agileits">
				<h4>One week VIP Membership</h4>
				<p class="contact-agile2"><b>Sign Up For Our One week VIP Membership by first paying Ksh 2500 to till number 5223519</b></p>
				<form  method="post" name="sentMessage" id="contactForm" >
					<div class="control-group form-group">
                        
                            <label class="contact-p1">Full Name:</label>
                            <input type="text" class="form-control" name="name" id="name" required >
                            <p class="help-block"></p>
                       
                    </div>	
                    <div class="control-group form-group">
                        
                            <label class="contact-p1">Phone Number:</label>
                            <input type="tel" class="form-control" name="phone" id="phone" required >
							<p class="help-block"></p>
						
                    </div>
                    <div class="control-group form-group">
                        
                            <label class="contact-p1">Email Address:</label>
                            <input type="email" class="form-control" name="email" id="email" required >
							<p class="help-block"></p>
						
                    </div>
                    
                    
                    <input type="submit" name="sub" value="Send Now" class="btn btn-primary">	
				</form>
							</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 contact-w3-agile1" data-aos="flip-right">
			<h4>Connect With Us</h4>
			<p class="contact-agile1"><strong>Phone :</strong>+254707418117</p>
			<p class="contact-agile1"><strong>Email :</strong> <a href="#">INFO@BETTWINTIPS.COM</a></p>
			
																
			<div class="social-bnr-agileits footer-icons-agileinfo">
				<ul class="social-icons3">
								<li><a href="#" class="fa fa-facebook icon-border facebook"> </a></li>
								<li><a href="#" class="fa fa-twitter icon-border twitter"> </a></li>
								<li><a href="#" class="fa fa-google-plus icon-border googleplus"> </a></li> 
								
							</ul>
			</div>
				<iframe src="images/Brr.png"></iframe>
		</div>
		<div class="clearfix"></div>
	</div>
</section>
 
<!-- /contact -->
			<div class="copy">
		        <p> Copyright &copy; 2021 . All Rights Reserved | Design by <a href="index.php">Bettwintips</a> </p>
		    </div>
<!--/footer -->
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- contact form -->
<script src="js/jqBootstrapValidation.js"></script>

<!-- /contact form -->	
<!-- Calendar -->
		<script src="js/jquery-ui.js"></script>
		<script>
				$(function() {
				$( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
				});
		</script>
<!-- //Calendar -->
<!-- gallery popup -->
<link rel="stylesheet" href="css/swipebox.css">
				<script src="js/jquery.swipebox.min.js"></script> 
					<script type="text/javascript">
						jQuery(function($) {
							$(".swipebox").swipebox();
						});
					</script>
<!-- //gallery popup -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smoth-scrolling -->
<!-- flexSlider -->
				<script defer src="js/jquery.flexslider.js"></script>
				<script type="text/javascript">
				$(window).load(function(){
				  $('.flexslider').flexslider({
					animation: "slide",
					start: function(slider){
					  $('body').removeClass('loading');
					}
				  });
				});
			  </script>
			<!-- //flexSlider -->
<script src="js/responsiveslides.min.js"></script>
			<script>
						// You can also use "$(window).load(function() {"
						$(function () {
						  // Slideshow 4
						  $("#slider4").responsiveSlides({
							auto: true,
							pager:true,
							nav:false,
							speed: 500,
							namespace: "callbacks",
							before: function () {
							  $('.events').append("<li>before event fired.</li>");
							},
							after: function () {
							  $('.events').append("<li>after event fired.</li>");
							}
						  });
					
						});
			</script>
		<!--search-bar-->
		<script src="js/main.js"></script>	
<!--//search-bar-->
<!--tabs-->
<script src="js/easy-responsive-tabs.js"></script>
<script>
$(document).ready(function () {
$('#horizontalTab').easyResponsiveTabs({
type: 'default', //Types: default, vertical, accordion           
width: 'auto', //auto or any width like 600px
fit: true,   // 100% fit in a container
closed: 'accordion', // Start closed if in accordion view
activate: function(event) { // Callback function if tab is switched
var $tab = $(this);
var $info = $('#tabInfo');
var $name = $('span', $info);
$name.text($tab.text());
$info.show();
}
});
$('#verticalTab').easyResponsiveTabs({
type: 'vertical',
width: 'auto',
fit: true
});
});
</script>
<!--//tabs-->
<!-- smooth scrolling -->
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1280,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	
	<div class="arr-w3ls">
	<a href="#home" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	</div>
	
<!-- //smooth scrolling -->
<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>
</body>
</html>

