// Validate entries in PAYE form

function validatePaye(frmPaye) 
{
	var numMonths = parseFloat(document.frmPaye.txtPayPeriod.value);
	var taxablePay = parseFloat(document.frmPaye.txtTaxablePay.value);
	var insureRelief = parseFloat(document.frmPaye.txtInsureRelief.value);
	
	// Validate pay period
	if (isNaN(numMonths)) 
	{
		alert("Please enter a valid number for the pay period.");
		return false;
	}
	
	if (numMonths < 1 || numMonths > 12) 
	{
		alert("Pay period should be between 1 and 12 months.");
		return false;
	}
		
	// Validate taxable pay
	if (isNaN(taxablePay)) 
	{
		alert("Please enter a valid number for taxable pay.");
		return false;
	}
	
	if (taxablePay < 0) 
	{
		alert("Taxable pay cannot be less than zero.");
		return false;
	}
	
	// Validate insurance relief
	if (isNaN(insureRelief)) 
	{
		alert("Please enter a valid number for insurance relief.");
		return false;
	}
	
	if (insureRelief < 0) 
	{
		alert("Insurance relief cannot be less than zero.");
		return false;
	}
	
	return true;
}

// Initialise PAYE form from cookie settings

function getCookie()
{
	if (document.cookie == "") return;	// no cookies
	
	// look for deduCalc cookie
	var cookieArray = document.cookie.split(";");
	for (var i=0; i<cookieArray.length; i++)
	{
		// extract cookie name
		var cookieValue = cookieArray[i].split("=");
		var cookieName = cookieValue[0];
		while (cookieName.charAt(0)==' ')
			cookieName = cookieName.substring(1, cookieName.length);			
			
		if (cookieName.indexOf("payeCalc2021") == 0)
		{
			// cookie found, initialise form
			var year = cookieValue[1].split("&")[0];
			var numMonths = cookieValue[1].split("&")[1];
			var showWorking = cookieValue[1].split("&")[2];
			
			// year
			var selYear = document.frmPaye.selYear;
			if (year == "2021")
				selYear.selectedIndex = 0;
				
			// pay period
			document.frmPaye.txtPayPeriod.value = numMonths;
	
			// show working
			var chkWorking = document.frmPaye.chkWorking;
			if (showWorking == "true")
				chkWorking.checked = true; 
			else
				chkWorking.checked = false; 			
						
			return;
		}
	}
}
// Update cookie with PAYE form settings	
function setCookie()
{
	var expiryDate = new Date();
	expiryDate.setTime(expiryDate.getTime() + 180*24*60*60*1000);	// 180 days from now
	
	// year
	var year = "";
	var selYear = document.frmPaye.selYear;	
	
	switch (selYear.selectedIndex)			
	{
	case 0:
		year = "2021";
		break;
	}
	// pay period
	var numMonths = parseFloat(document.frmPaye.txtPayPeriod.value);
			
	// show working
	var showWorking = "";
	var chkWorking = document.frmPaye.chkWorking;
	
	if (chkWorking.checked)
		showWorking="true";
	else
		showWorking="false";
		
	// update cookie
	document.cookie = "payeCalc2021=" + year + "&" + numMonths + "&" + showWorking + ";expires=" + 
		expiryDate.toUTCString() + ";path=/";
}