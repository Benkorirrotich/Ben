<?php
$username = "root";
$password = "";
$db = "db_name";

$dns = "mysql:host=localhost;dbname=$db;charset=utf8mb4";
$conn = new PDO($dns,$username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$sql = "select * from mine where username = ? ";

$stmt1 = $conn->prepare($sql);
$stmt1->execute(array($_POST['user']));
$all = $stmt1->fetchAll(); ?>

<div class="controls">
    <select  data-rel="chosen"  name="degree_id" id="selectError">
        <?php 
        foreach($all as $nt) { 
            echo "<option value =$nt[id]>$nt[name]</option>";
        }
        ?>
    </select>
</div>