<?php
	include 'includes/connection.php';
	$id = $_REQUEST['id'];
		$query = "DELETE FROM beauty WHERE id = '$id'";
	$result = $con->query($query);
	if($result === TRUE){
		echo "<script type = \"text/javascript\">
					alert(\"you are about to delete this records \");
					window.location = (\"fullbeauty.php\")
				</script>";
	}
?>
