<div class="brand clearfix">
	
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#"> <img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> <b style='text-align:center;Color:green' href="#" class="ts-avatar hidden-side" alt=""><?=$_SESSION['fname']?></b> <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><b><a style='Color:white;'    href="dashboard.php">Back</a></b></li>
					<li><b ><a style='Color:red;'    href="./logout.php">Logout</a></b></li>
				</ul>
			</li>
		</ul>
	</div>
