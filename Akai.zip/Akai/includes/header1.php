

	<div class="brand clearfix">
	<center style="color:white;"><a href="index.php" style="font-size: 30px;">Ideal Barber and Beauty Parlour</a></center>  
		<span class="menu-btn"><i class="fa fa-bars" ></i></span>
			
			
			
				
				
				
					
			
	</div>