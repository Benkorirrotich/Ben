
<footer>
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-md-push-6 text-center">
          <div class="footer_widget">
            <center><p class="copy-right">&copy; Developed By <a href=""> BKO Technologies (0707418117)</a></p></center>
            
          </div>
        </div>
      
      </div>
    </div>
  </div>
</footer>
