<?php
	$con = mysqli_connect("localhost", "root", "", "idealbarber") or die ("Database Connection Failed!!!");
?>