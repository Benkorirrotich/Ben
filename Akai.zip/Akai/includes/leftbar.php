	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
				<li class="ts-label">Main</li>
					<li><a href="#"><i class="fa fa-user"></i>Staff</a>
				<ul>
				<li><a href="addstaff.php"><i class="fa fa-user"></i>Add</a></li>
				<li><a href="Managestaff.php">View Staff</a></li>
				</ul></li>
				<li><a href="#"><i class="fa fa-user"></i>Beauty Services</a>
				<ul>
				<li><a href="beauty.php">Add Service</a></li>
				<li><a href="./manage_beauty.php">Daily Reports</a></li>
				</ul></li>
					<li><a href="#"><i class="fa fa-user"></i>Barber Services</a>
				<ul>
				<li><a href="haircut.php">Add Service</a></li>
				<li><a href="manage_haircut.php">Daily Reports</a></li>
				</ul></li>
					<li><a href="#"><i class="fa fa-user"></i>Full Reports</a>
				<ul>
				<li><a href="fullbeauty.php">Beauticians Reports</a></li>
				<li><a href="fullbarber.php">Barbers Reports</a></li>
				</ul></li>
					<li><a href="#"><i class="fa fa-user"></i>Customers Contacts</a>
				<ul>
				<li><a href="client.php"><i class="fa fa-user"></i>Add Contact</a></li>
				<li><a href="Manageclient.php">View Contact</a></li>
				</ul></li>
				<li><a href="https://bulksms.afrinettelecom.co.ke"><i class="fa fa-user"></i>Send Bulk SMS</a></li> 
					<li><a href="#"><i class="fa fa-user"></i>Off Duty</a>
				<ul>
				<li><a href="duty.php"><i class="fa fa-user"></i>Add</a></li>
				<li><a href="Manageduty.php">View Off Duties</a></li>
				</ul></li>
				<li><a href="#"><i class="fa fa-user"></i>Expenses</a>
				<ul>
				<li><a href="expenses.php"><i class="fa fa-user"></i>Add</a></li>
				<li><a href="manageexpenses.php">View Expenses</a></li>
				<li><a href="history.php">Expenses History</a></li>
				</ul></li>
						<li><a href="manage-admin.php"><i class="fa fa-user"></i>Manange Users</a></li>
						
			</ul>
		</nav>